
<?php
// Conectar ao banco de dados
if (!function_exists('connect_db')) {
    function connect_db() {
        $servername = "localhost";
        $username = "web";
        $password = "web";
        $dbname = "chat";

        // Cria conexão
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verifica conexão
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }
}
?>

