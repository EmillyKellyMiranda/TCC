-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 16/10/2023 às 15:18
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `chat`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `chatrooms`
--

CREATE TABLE `chatrooms` (
  `id` int(11) NOT NULL,
  `user1_id` int(11) DEFAULT NULL,
  `user2_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `chatrooms`
--

INSERT INTO `chatrooms` (`id`, `user1_id`, `user2_id`) VALUES
(3, 1, 1),
(1, 1, 3),
(7, 1, 6),
(8, 1, 7),
(2, 3, 3),
(9, 3, 6),
(5, 4, 4),
(4, 4, 5),
(6, 6, 7),
(10, 8, 9),
(13, 8, 14),
(16, 8, 19),
(11, 10, 11),
(12, 12, 13),
(14, 14, 15),
(15, 16, 17),
(17, 20, 21),
(18, 20, 22),
(20, 22, 24),
(19, 23, 24);

-- --------------------------------------------------------

--
-- Estrutura para tabela `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `chatroom_id` varchar(255) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `chat_id` varchar(255) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `messages`
--

INSERT INTO `messages` (`id`, `chatroom_id`, `sender_id`, `message`, `timestamp`, `chat_id`, `sender_name`) VALUES
(1, '1-3', 1, 'cara', '2023-09-25 04:20:24', NULL, NULL),
(2, NULL, 1, 'doido', '2023-09-25 04:24:43', '1-3', NULL),
(3, NULL, 3, 'a', '2023-09-25 04:25:01', '3-3', NULL),
(4, '1', 1, 'fuck you', '2023-09-25 04:31:17', NULL, NULL),
(5, '2', 3, 'ca', '2023-09-25 04:31:33', NULL, NULL),
(6, '2', 3, 'ca', '2023-09-25 04:31:34', NULL, NULL),
(7, '2', 3, 'ca', '2023-09-25 04:31:34', NULL, NULL),
(8, '1', 1, 'ca', '2023-09-25 04:55:39', NULL, 'lixo'),
(9, '1', 1, 'aa', '2023-09-25 04:59:02', NULL, 'lixo'),
(10, '3', 1, 'a', '2023-09-25 04:59:19', NULL, 'christian'),
(11, '3', 1, 'as', '2023-09-25 04:59:26', NULL, 'christian'),
(12, '4', 4, 'Oi jose', '2023-09-25 05:00:34', NULL, 'Otavio'),
(13, '4', 4, 'Oi otavio', '2023-09-25 05:00:55', NULL, 'Jose'),
(14, '4', 4, 'a', '2023-09-25 05:05:23', NULL, 'Otavio'),
(15, '4', 4, 'asa', '2023-09-25 05:05:26', NULL, 'Otavio'),
(16, '4', 4, 'asaasd', '2023-09-25 05:05:27', NULL, 'Otavio'),
(17, '4', 4, 'a', '2023-09-25 05:05:31', NULL, 'Jose'),
(18, '4', 4, 'adsadsda', '2023-09-25 05:05:36', NULL, 'Jose'),
(19, '4', 4, 'adsadsdaasd', '2023-09-25 05:05:37', NULL, 'Jose'),
(20, '4', 4, 'asaasd', '2023-09-25 05:05:44', NULL, 'Otavio'),
(21, '4', 4, 'a', '2023-09-25 05:11:43', NULL, 'Otavio'),
(22, '4', 4, 'as', '2023-09-25 05:11:47', NULL, 'Otavio'),
(23, '4', 4, 'asss', '2023-09-25 05:11:49', NULL, 'Otavio'),
(24, '6', 6, 'oi', '2023-09-25 05:17:38', NULL, 'Emilly'),
(25, '6', 6, 'tchau', '2023-09-25 05:18:06', NULL, 'Thais'),
(26, '7', 1, '', '2023-09-25 14:41:29', NULL, 'christian'),
(27, '7', 1, '', '2023-09-25 14:41:30', NULL, 'christian'),
(28, '7', 1, 'as', '2023-09-25 14:41:32', NULL, 'christian'),
(29, '7', 1, 'sa', '2023-09-25 14:42:20', NULL, 'christian'),
(30, '9', 3, 'ca', '2023-09-25 14:54:42', NULL, 'lixo'),
(31, '9', 3, 'ta doido', '2023-09-25 14:54:47', NULL, 'lixo'),
(32, '9', 3, 'a', '2023-09-25 15:02:03', NULL, 'lixo'),
(33, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(34, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(35, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(36, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(37, '9', 3, 'a', '2023-09-25 15:13:31', NULL, 'lixo'),
(38, '9', 3, 'aaa', '2023-09-25 15:13:34', NULL, 'lixo'),
(39, '9', 3, 'a', '2023-09-25 15:13:37', NULL, 'lixo'),
(40, '7', 1, 'va', '2023-09-25 15:16:23', NULL, 'christian'),
(41, '7', 1, 'va', '2023-09-25 15:16:30', NULL, 'christian'),
(42, '2', 3, 'a', '2023-09-25 15:16:48', NULL, 'lixo'),
(43, '2', 3, 'asd', '2023-09-25 15:34:24', NULL, 'lixo'),
(44, '2', 3, 'asd', '2023-09-25 15:34:24', NULL, 'lixo'),
(45, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(46, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(47, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(48, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(49, '2', 3, 'asd', '2023-09-25 15:34:26', NULL, 'lixo'),
(50, '1', 1, 'sa', '2023-09-25 15:40:25', NULL, 'christian'),
(51, '1', 1, 'saasd', '2023-09-25 15:40:30', NULL, 'christian'),
(52, '2', 3, 'a', '2023-09-25 15:42:23', NULL, 'lixo'),
(53, '1', 1, 'a', '2023-09-25 15:43:16', NULL, 'christian'),
(54, '1', 1, 'aasf', '2023-09-25 15:43:18', NULL, 'christian'),
(55, '1', 1, 'aasfaf', '2023-09-25 15:43:20', NULL, 'christian'),
(56, '1', 1, 'aasfafasf', '2023-09-25 15:43:21', NULL, 'christian'),
(57, '10', 8, 'a', '2023-09-25 17:18:33', NULL, 'Rodriguinho'),
(58, '10', 8, 'oi', '2023-09-25 17:18:45', NULL, 'Rodrigao'),
(59, '10', 8, 'ol', '2023-09-25 17:20:17', NULL, 'Rodrigao'),
(60, '10', 8, 'a', '2023-09-25 17:23:38', NULL, 'Rodrigao'),
(61, '10', 8, 'aa', '2023-09-25 17:23:40', NULL, 'Rodrigao'),
(62, '10', 8, 'aa', '2023-09-25 17:23:40', NULL, 'Rodrigao'),
(63, '10', 8, 'aa', '2023-09-25 17:23:40', NULL, 'Rodrigao'),
(64, '10', 8, 'aa', '2023-09-25 17:23:40', NULL, 'Rodrigao'),
(65, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(66, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(67, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(68, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(69, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(70, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(71, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(72, '10', 8, 'aa', '2023-09-25 17:23:41', NULL, 'Rodrigao'),
(73, '10', 8, 'aa', '2023-09-25 17:23:42', NULL, 'Rodrigao'),
(74, '10', 8, 'aa', '2023-09-25 17:23:42', NULL, 'Rodrigao'),
(75, '10', 8, 'aa', '2023-09-25 17:23:42', NULL, 'Rodrigao'),
(76, '10', 8, 'aa', '2023-09-25 17:23:42', NULL, 'Rodrigao'),
(77, '10', 8, 'aa', '2023-09-25 17:23:42', NULL, 'Rodrigao'),
(78, '10', 8, 'aa', '2023-09-25 17:23:42', NULL, 'Rodrigao'),
(79, '10', 8, 'as', '2023-09-25 17:29:08', NULL, 'Rodrigao'),
(80, '10', 8, 'as', '2023-09-25 17:29:10', NULL, 'Rodrigao'),
(81, '10', 8, 'as', '2023-09-25 17:29:11', NULL, 'Rodrigao'),
(82, '10', 8, 'as', '2023-09-25 17:29:11', NULL, 'Rodrigao'),
(83, '10', 8, 'as', '2023-09-25 17:29:12', NULL, 'Rodrigao'),
(84, '10', 8, 'as', '2023-09-25 17:29:13', NULL, 'Rodrigao'),
(85, '10', 8, 'as', '2023-09-25 17:29:13', NULL, 'Rodrigao'),
(86, '10', 8, 'as', '2023-09-25 17:29:13', NULL, 'Rodrigao'),
(87, '10', 8, 'as', '2023-09-25 17:29:13', NULL, 'Rodrigao'),
(88, '10', 8, 'as', '2023-09-25 17:29:13', NULL, 'Rodrigao'),
(89, '10', 8, 'as', '2023-09-25 17:29:14', NULL, 'Rodrigao'),
(90, '10', 8, 'as', '2023-09-25 17:29:14', NULL, 'Rodrigao'),
(91, '10', 8, 'asssf', '2023-09-25 17:29:17', NULL, 'Rodrigao'),
(92, '10', 8, 'eai', '2023-09-25 17:29:44', NULL, 'Rodrigao'),
(93, '10', 8, 'salve', '2023-09-25 17:29:56', NULL, 'Rodriguinho'),
(94, '10', 8, 'salve', '2023-09-25 17:30:13', NULL, 'Rodriguinho'),
(95, '10', 8, 'Opa!', '2023-09-25 17:32:04', NULL, 'Rodriguinho'),
(96, '11', 10, 'Eai, Josefina!', '2023-09-25 17:37:49', NULL, 'Carlinhos'),
(97, '11', 10, 'Salve, filho da puta!', '2023-09-25 17:38:00', NULL, 'Josefina'),
(98, '11', 10, 'a', '2023-09-25 17:42:05', NULL, 'Carlinhos'),
(99, '12', 12, 'Salve, Yas!', '2023-09-25 17:43:44', NULL, 'Meetz'),
(100, '12', 12, 'Salve, filho da PUTA!', '2023-09-25 17:43:53', NULL, 'Yasuicida'),
(101, '12', 12, 'kkkkkkkk doentola', '2023-09-25 17:44:00', NULL, 'Meetz'),
(102, '12', 12, 'si fude kkkk', '2023-09-25 17:44:05', NULL, 'Yasuicida'),
(103, '13', 8, 'a', '2023-09-25 17:49:14', NULL, 'Doido'),
(104, '13', 8, 'a', '2023-09-25 17:49:15', NULL, 'Doido'),
(105, '13', 8, 's', '2023-09-25 17:49:16', NULL, 'Doido'),
(106, '13', 8, 'u u aa ', '2023-09-25 17:49:24', NULL, 'Doido'),
(107, '13', 8, '', '2023-09-25 17:49:40', NULL, 'Doido'),
(108, '13', 8, 'safsaf', '2023-09-25 17:49:42', NULL, 'Doido'),
(109, '12', 12, 'asf', '2023-09-25 17:49:48', NULL, 'Yasuicida'),
(110, '12', 12, 'saf', '2023-09-25 17:49:49', NULL, 'Yasuicida'),
(111, '12', 12, 'a', '2023-09-25 17:51:05', NULL, 'Yasuicida'),
(112, '12', 12, 'saf', '2023-09-25 17:51:06', NULL, 'Yasuicida'),
(113, '12', 12, 'gdg', '2023-09-25 17:51:14', NULL, 'Yasuicida'),
(114, '12', 12, 'dg', '2023-09-25 17:51:15', NULL, 'Yasuicida'),
(115, '12', 12, 'a', '2023-09-25 17:57:54', NULL, 'Yasuicida'),
(116, '12', 12, 'fsa', '2023-09-25 17:57:55', NULL, 'Yasuicida'),
(117, '12', 12, 'asf', '2023-09-25 17:57:56', NULL, 'Yasuicida'),
(118, '12', 12, 'saf', '2023-09-25 17:57:57', NULL, 'Yasuicida'),
(119, '12', 12, 'fas', '2023-09-25 17:57:58', NULL, 'Yasuicida'),
(120, '12', 12, 'fas', '2023-09-25 17:58:00', NULL, 'Yasuicida'),
(121, '12', 12, 'asfasf 2', '2023-09-25 17:58:04', NULL, 'Yasuicida'),
(122, '12', 12, '22', '2023-09-25 17:58:05', NULL, 'Yasuicida'),
(123, '12', 12, '222', '2023-09-25 17:58:06', NULL, 'Yasuicida'),
(124, '12', 12, '22', '2023-09-25 17:58:07', NULL, 'Yasuicida'),
(125, '13', 8, 'as', '2023-09-25 17:59:16', NULL, 'Doido'),
(126, '13', 8, 'f', '2023-09-25 17:59:17', NULL, 'Doido'),
(127, '13', 8, '2', '2023-09-25 17:59:18', NULL, 'Doido'),
(128, '13', 8, 'af', '2023-09-25 17:59:19', NULL, 'Doido'),
(129, '13', 8, 'z', '2023-09-25 17:59:21', NULL, 'Doido'),
(130, '13', 8, 'z', '2023-09-25 17:59:23', NULL, 'Doido'),
(131, '13', 8, '', '2023-09-25 17:59:24', NULL, 'Doido'),
(132, '14', 14, 'a', '2023-09-25 17:59:56', NULL, 'as'),
(133, '14', 14, '3', '2023-09-25 17:59:57', NULL, 'as'),
(134, '14', 14, '5', '2023-09-25 17:59:59', NULL, 'as'),
(135, '14', 14, 'asd', '2023-09-25 18:00:19', NULL, 'Doido'),
(136, '14', 14, 'fa', '2023-09-25 18:00:24', NULL, 'Doido'),
(137, '15', 16, 'Olá, Emilly!', '2023-09-25 18:01:34', NULL, 'Thais'),
(138, '15', 16, 'Olá, Thais! Tudo bem?', '2023-09-25 18:01:44', NULL, 'Emilly'),
(139, '15', 16, 'Tudo sim! =)', '2023-09-25 18:01:52', NULL, 'Thais'),
(140, '15', 16, 'TCHAU', '2023-09-25 18:01:57', NULL, 'Emilly'),
(141, '15', 16, 'Q ISSO', '2023-09-25 18:02:00', NULL, 'Thais'),
(142, '15', 16, 'a', '2023-09-25 18:06:39', NULL, 'Emilly'),
(143, '15', 16, 'sf', '2023-09-25 18:06:42', NULL, 'Emilly'),
(144, '15', 16, 'fs', '2023-09-25 18:06:43', NULL, 'Emilly'),
(145, '16', 8, 'a', '2023-09-25 18:09:11', NULL, 'A'),
(146, '16', 8, 's', '2023-09-25 18:09:12', NULL, 'A'),
(147, '16', 8, 'f', '2023-09-25 18:09:13', NULL, 'A'),
(148, '16', 8, 'g', '2023-09-25 18:09:14', NULL, 'A'),
(149, '16', 8, '2', '2023-09-25 18:09:15', NULL, 'A'),
(150, '16', 8, 'a', '2023-09-25 18:09:29', NULL, 'A'),
(151, '16', 8, 'b', '2023-09-25 18:09:34', NULL, 'A'),
(152, '16', 8, 's', '2023-09-25 18:10:11', NULL, 'A'),
(153, '17', 20, 'Olá, Emilly!', '2023-09-25 18:13:20', NULL, 'Thais'),
(154, '18', 20, 'Oi, Christian!', '2023-09-25 18:14:54', NULL, 'Thais'),
(155, '18', 20, 'Opa, Thais!', '2023-09-25 18:15:02', NULL, 'Christian'),
(156, '18', 20, 'Tudo bem?', '2023-09-25 18:15:07', NULL, 'Thais'),
(157, '18', 20, 'S!', '2023-09-25 18:15:09', NULL, 'Christian'),
(158, '18', 20, 'Ta!', '2023-09-25 18:15:12', NULL, 'Thais'),
(159, '18', 20, '=)', '2023-09-25 18:15:16', NULL, 'Christian'),
(160, '19', 23, 'Salve, PORRA!', '2023-09-26 05:22:59', NULL, 'Juan'),
(161, '19', 23, 'CARALHO', '2023-09-26 05:23:04', NULL, 'Pedro'),
(162, '19', 23, 'Q ISSO FILHO?', '2023-09-26 05:23:11', NULL, 'Juan'),
(163, '19', 23, 'DOIDO', '2023-09-26 05:23:17', NULL, 'Pedro'),
(164, '19', 23, 'KKAKA', '2023-09-26 05:23:22', NULL, 'Juan'),
(165, '19', 23, 'SAD', '2023-09-26 05:23:27', NULL, 'Juan'),
(166, '19', 23, '', '2023-09-26 05:23:27', NULL, 'Juan'),
(167, '19', 23, '', '2023-09-26 05:23:28', NULL, 'Juan'),
(168, '19', 23, '', '2023-09-26 05:23:29', NULL, 'Juan'),
(169, '19', 23, '', '2023-09-26 05:23:30', NULL, 'Juan'),
(170, '19', 23, '', '2023-09-26 05:23:30', NULL, 'Juan'),
(171, '19', 23, 'QAAA', '2023-09-26 05:24:14', NULL, 'Juan'),
(172, '19', 23, 'aaa', '2023-09-26 05:24:15', NULL, 'Juan'),
(173, '19', 23, 'aaa', '2023-09-26 05:24:16', NULL, 'Juan'),
(174, '19', 23, 'cascasc', '2023-09-26 05:24:18', NULL, 'Pedro'),
(175, '19', 23, 'ascasc', '2023-09-26 05:24:19', NULL, 'Pedro'),
(176, '19', 23, 'ascsac', '2023-09-26 05:24:20', NULL, 'Pedro'),
(177, '19', 23, 'ascsac', '2023-09-26 05:24:21', NULL, 'Pedro');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(20, 'Thais', '$2y$10$sFT0Yx5S1EYvbKA4yUH7xuiX7uz7iwZhRjy5aiQM.TdzCF.42Cy92'),
(21, 'Emilly', '$2y$10$Zt/cM9IeMTrXE1cdg2G/huWC3ZIK3ZnOwbJ08K7CP9ChpRZ6n5P/S'),
(22, 'Christian', '$2y$10$OoGsZlR97FqiNDS5G292suuSYu.gwnyVu6l.rZlyVyRcfxQvqVtoC'),
(23, 'Juan', '$2y$10$LwmpSXL53r8BVMEeoRXsd.prHNktniSK3byYaYOwUI1XJCgcCZrGC'),
(24, 'Pedro', '$2y$10$UtqbSBtnJ38VDyQy/3uwb.Df39WLO3yhnRRBqz9OZba1rRgUtVKPK'),
(25, 'cara', '$2y$10$DEJUSHmyndDJxPsnbGMXmebF05KoPE6GIPsgH.s6cMpHP4BsZAjTy');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `chatrooms`
--
ALTER TABLE `chatrooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user1_id` (`user1_id`,`user2_id`);

--
-- Índices de tabela `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `chatrooms`
--
ALTER TABLE `chatrooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
