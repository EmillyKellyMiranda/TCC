<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <style>
        /* Reset de estilos */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Container principal */
        #chat-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            font-family: Arial, sans-serif;
            background-color: #36393f;
            color: white;
        }

        /* Cabeçalho */
        #header {
            background-color: #202225;
            padding: 15px;
            text-align: center;
            font-size: 1.5em;
        }

        /* Área das mensagens */
        #messages {
            flex-grow: 1;
            overflow-y: auto;
            padding: 20px;
        }

        /* Mensagem individual */
        .message {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            background-color: #40444b;
        }

        /* Input de mensagem */
        #message-input {
            display: flex;
            border-top: 1px solid #4a4d52;
        }

        /* Input de texto */
        #message-input input {
            flex-grow: 1;
            padding: 10px;
            border: none;
            border-radius: 0;
        }

        /* Botão de enviar */
        #message-input button {
            background-color: #7289da;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
        }

        #message-input button:hover {
            background-color: #5b6eae;
        }
    </style>
</head>
<body>
    <div id="chat-container">
        <div id="header">Chat</div>
        <div id="messages"></div>
        <div id="message-input">
            <input type="text" placeholder="Digite sua mensagem..."/>
            <button>Enviar</button>
        </div>
    </div>
    <script src="frontend.js"></script>
</body>
</html>
