"use strict"; 
window.onload = function() {  


    document.addEventListener('DOMContentLoaded', function() {
        var selectElement = document.getElementById('tipo_arte');
        selectElement.addEventListener('change', function() {
            var selectedOption = this.options[this.selectedIndex];
            for (var i = 0; i < this.options.length; i++) {
                this.options[i].disabled = false;
            }
            selectedOption.disabled = true;
        });
    });
}