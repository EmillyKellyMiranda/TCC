function updatePhoto(event) {
    const image = document.getElementById("profile-pic");
    image.src = URL.createObjectURL(event.target.files[0]);
}

function updateDescription() {
    const description = document.getElementById("description");
    alert("Descrição atualizada:\n" + description.value);
}