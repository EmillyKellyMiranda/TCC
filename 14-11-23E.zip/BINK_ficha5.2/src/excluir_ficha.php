<script>
    function excluirFicha(idFicha) {
        if (confirm("Tem certeza de que deseja excluir esta ficha?")) {
            // Envia a solicitação para o arquivo PHP
            const formData = new FormData();
            formData.append('ficha_id', idFicha);

            fetch('excluir_ficha.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    // Recarrega a página ou atualiza os cards após a exclusão
                    location.reload();
                } else {
                    // Tratar erros ou dar feedback ao usuário
                    console.error('Erro ao excluir ficha');
                }
            })
            .catch(error => console.error('Erro:', error));
        }
    }
</script>
