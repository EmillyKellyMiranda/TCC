<?php
    session_start();
    include ("../include/cabecalho_logged.php");

    require("../database/funcoes.php");

    if (!isset($_SESSION["usuario_logado"])){
        header("Location: ../public/index.php");
    }

    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
    $meu_id = $usuario['id_cliente'];

    $id_selecionado = $_SESSION["id_contatoADD"];
    $conexao1 = obterConexao();
    $sql1 = "SELECT id_cliente FROM artista WHERE id_artista = ?";
    $stmt1 = mysqli_prepare($conexao1, $sql1);
    mysqli_stmt_bind_param($stmt1, "i", $id_selecionado);
    mysqli_stmt_execute($stmt1);
    $resultado = mysqli_stmt_get_result($stmt1);

    while ($row = mysqli_fetch_assoc($resultado)) {
        // $row conterá os dados da linha do resultado
        $id_user = $row['id_cliente'];
        // Faça o que quiser com $id_cliente
    }
    $array_selecionado= buscarUsuarioPorId($id_user);
    $id_user_selecionado = $array_selecionado['id_cliente'];

?>


<!DOCTYPE html>
<html lang="pt">
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <style>
        body{
            background-color: #000000;
        }

        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }
        
        .container {
            display: absolute;
            /*margin: 100px;
            float: left;*/
            justify-content: space-between;
            align-items: flex;
            margin-top: 200px; /* Ajuste a margem superior conforme necessário */
            color:#ffffff;
            width:600px;
            border: solid 1px;
            border-color: rgb(0, 255, 191); 
            
        }

        li{
            color:rgb(0, 255, 191);
        }

        

        
        .btn-custom {
                display: flex;
                border-radius: 10px;
                color: #ffffff;
                background-color: #27332e;
                border-color: #00ffda;
                transition: all 0.3s ease; /* para suavizar a transição */
                text-align: flex;
                justify-content: space-between;
                margin-top: 200px;
                margin-left: 250px;

            }
    </style>
</head>
<body>

        <div class="container">

        

        
            <?php
                $conexao = obterConexao();

                if ($_SERVER["REQUEST_METHOD"] == "POST"){
                    if (isset($_POST["btn_add_contato"])) {
                        $valorDoBotao = $_POST["btn_add_contato"];

                        if ($valorDoBotao !== null) {
                            if ($valorDoBotao == 0) {
                                $btn_status = 1;
                                $btn_texto = "Remover contato";

                                $sql_cadastra = "INSERT INTO contatos (id_cliente, id_addContato, nome_addContato, btn_status, btn_texto) values (?, ?, ?, ?, ?)";
                                $stmt_cadastra = mysqli_prepare($conexao, $sql_cadastra);
                                mysqli_stmt_bind_param($stmt_cadastra, "iisis", $meu_id, $id_user_selecionado, $array_selecionado['nick'], $btn_status, $btn_texto);
                                mysqli_stmt_execute($stmt_cadastra);
                                echo "<h1>Parabéns!! Você adicionou " . $array_selecionado['nick'] . " aos seus contatos ^ - ^</h1>";
                            } else {

                                $sql_exclui = "DELETE FROM contatos WHERE id_cliente = ? AND id_addContato = ?";
                                $stmt_exclui = mysqli_prepare($conexao, $sql_exclui);
                                mysqli_stmt_bind_param($stmt_exclui, "ii", $meu_id, $id_user_selecionado);
                                mysqli_stmt_execute($stmt_exclui);

                                echo "<h1>Você excluiu " . $array_selecionado['nick'] . " aos seus contatos!</h1>";

                                


                            }
                        }    
                    }
                }
            ?>

            <button class="btn btn-custom" style="position:fixed; top:140px; backgroud-color:;" type="button" onclick="goBack()">
                Voltar
            </button>
            
        </div>

        <script>
            function goBack() {
                window.history.back();
            }
        </script>
    
    
</body>
</html>





