<?php
    require ("../database/funcoes.php");
    include("../include/cabecalho_unlogged.php");
  
?>
<?php
    require_once("../database/funcoes.php");
    
    if(isset($_POST["codigo"])) {
        $codigo = $_POST["codigo"];
        
        if($codigo == $_SESSION["token"]) {
            
            header("Location: redefine_senha.php");
        } else {
            echo "<h3 style='margin-left: 330px; color:red;'>Código incorreto!</h3>";
        }
    }
?>

<!DOCTYPE html>
<html>
<body>
<div class="page-wrapper"></div>
<link rel="stylesheet" type="text/css" href="../css/style_redefinesenha.css" />
<div class="container">
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="50%" y1="0%" x2="50%" y2="100%"><stop offset="5%" stop-color="#000000"></stop><stop offset="95%" stop-color="#000000"></stop></linearGradient></defs><path d="M 0,700 C 0,700 0,350 0,350 C 148.2666666666667,411.3333333333333 296.5333333333334,472.66666666666663 479,439 C 661.4666666666666,405.33333333333337 878.1333333333332,276.6666666666667 1044,246 C 1209.8666666666668,215.33333333333331 1324.9333333333334,282.66666666666663 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1.0" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path></svg>   
<div class="row">
    <div class="col-md-6">
    <h3>Enviamos um <span>código</span> no email fornecido. Verifique a caixa de spam caso não encontre.<h3>
    <form action="confirma_codigo.php" method="post">
        <label for="codigo">Digite o código recebido por email:</label><br>
        <input type="text" id="codigo" name="codigo" required><br>
        <input class="btn btn-custom-success" type="submit" value="Confirmar código">
    </form> 
    </div>
    <div class="col-md-6">
      <div class="imagem mb-6">
        <img src="../img/arte.png" alt="Imagem" class="img-fluid">
      </div>
    </div>
</div>
</div>
</body>
</html>
