"use strict"; //esse comando é usado para impedir erros em razão de comandos indevidos (ex: não declarar "var" quando usar variaveis), torna o codigo mais seguro

//window.onload serve para que a function seja realizada assim q a pagina carregar (todo o codigo fica dentro dela)
window.onload = function() {  
    var btnPortifolio = document.getElementById("btn_curriculo");

    btnPortifolio.onclick = function (){
        
        var conteudo = document.getElementById("form_curriculo");

        conteudo.innerHTML = "<form action='btn_curriculo.php' method='post' id='editar_curriculo'>"+
        "<p><input type='text' name='localizacao' id='localizacao' placeholder='Localização do artista'></p>"+
        "<p><input type='text' name='sobre_artista' id='sobre_artista' placeholder='Descrição do artista'></p>"+
        "<p><input type='text' name='formacao' id='formacao' placeholder='Formação do artista'></p>"+
        "<p><input type='text' name='estilo_arte' id='estilo_arte' placeholder='Estilo do artista'></p>"+
        "<p><input type='text' name='contato' id='contato'  placeholder='Contato do artista'></p>"+
        "<p><button type=submit>Salvar</button></p>"+
        "</form>";
    }


 
}