"use strict";
window.onload = function () {
  var btnCurriculo = document.getElementById("btn_curriculo");

  btnCurriculo.onclick = function () {
    $('#modal').modal('show');
    populateUF();
  };

  var ufSelect = document.getElementById("uf");
  ufSelect.onchange = function () {
    populateCidades();
  };
};
$('#cancelar').on('click', function() {
  $('#modal').modal('hide');
});
function populateUF() {
  var ufSelect = document.getElementById("uf");
  fetch("https://servicodados.ibge.gov.br/api/v1/localidades/estados")
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      data.sort(function (a, b) {
        return a.nome.localeCompare(b.nome);
      });

      data.forEach(function (estado) {
        var option = document.createElement("option");
        option.value = estado.sigla;
        option.text = estado.nome;
        ufSelect.appendChild(option);
      });
    })
    .catch(function (error) {
      console.log("Ocorreu um erro ao carregar os estados: ", error);
    });
}

function populateCidades() {
  var ufSelect = document.getElementById("uf");
  var cidadesSelect = document.getElementById("cidades");
  var estadoSelecionado = ufSelect.value;
  cidadesSelect.innerHTML = "<option>Carregando...</option>";

  fetch(
    "https://servicodados.ibge.gov.br/api/v1/localidades/estados/" +
      estadoSelecionado +
      "/municipios"
  )
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      cidadesSelect.innerHTML = ""; // Limpa as opções anteriores
      data.forEach(function (cidade) {
        var option = document.createElement("option");
        option.value = cidade.nome;
        option.text = cidade.nome;
        cidadesSelect.appendChild(option);
      });
    })
    .catch(function (error) {
      console.log("Ocorreu um erro ao carregar as cidades: ", error);
    });
}
