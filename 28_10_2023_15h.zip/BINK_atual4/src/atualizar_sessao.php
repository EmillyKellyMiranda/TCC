<?php
// ESSE CÓDIGO TRABALHA JUNTO DE "chat.js" E SUA FUNÇÃO É PASSAR "$id_user"(chat.php) PARA UMA $_SESSION
session_start();

if (isset($_POST['id_user'])) {
    $_SESSION['id_user'] = $_POST['id_user'];
    echo 'Sessão atualizada com sucesso!';
} else {
    echo 'Parâmetro id_user ausente na solicitação.';
}
?>
