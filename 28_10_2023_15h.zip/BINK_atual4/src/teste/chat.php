<?php
    include("database/bd_conect.php");
    $conexao = Conexao();
    $sql = $conexao->query("SELECT * FROM chat1");
    while ($key = $sql->fetch_assoc()){
        echo "<h3>".$key['nome']."</h3>";
        echo "<p>".$key['mensagem']."</p>";
    }

?>