<?php
include("../database/funcoes.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit();
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
$conexao1 = obterConexao();
$sql1 = "SELECT id_artista FROM artista WHERE id_cliente = ?";
$stmt1 = mysqli_prepare($conexao1, $sql1);
mysqli_stmt_bind_param($stmt1, "i", $usuario["id_cliente"]);
mysqli_stmt_execute($stmt1);
$resultado = mysqli_stmt_get_result($stmt1);

$id_artista = null;
while ($row = mysqli_fetch_assoc($resultado)) {
    $id_artista = $row['id_artista'];
}
mysqli_close($conexao1);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome_producao = isset($_POST["nome_producao"]) ? $_POST["nome_producao"] : "";
    $arte = isset($_POST["tipo_arte"]) ? $_POST["tipo_arte"] : "";
    $tempo = isset($_POST["tempo"]) ? $_POST["tempo"] : "";
    $valorTotal = isset($_POST["valorTotal"]) ? $_POST["valorTotal"] : "";

    $etapas = [];
    for ($i = 1; $i <= 10; $i++) {
        $etapa = isset($_POST["etapa$i"]) ? $_POST["etapa$i"] : "";
        $etapas["etapa" . $i] = $etapa;
    }

    $conexao = obterConexao();

    if ($conexao) {
        cadastrarFicha($id_artista, $nome_producao, $arte, $tempo, $valorTotal, $etapas);
        mysqli_close($conexao);

        header("Location: imprime_ficha.php");
        exit();
    } else {
        echo "Erro na conexão com o banco de dados!";
    }
}

function cadastrarFicha($id_cliente_artista, $nome_producao, $arte, $tempo, $valorTotal, $etapas) {
    $conexao = obterConexao();
    $sql = "INSERT INTO ficha (id_artista, nome_producao, arte, tempo, valorTotal, etapa1, etapa2, etapa3, etapa4, etapa5, etapa6, etapa7, etapa8, etapa9, etapa10) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexao, $sql);

 if ($stmt === false) {
        die("Erro na preparação da declaração SQL: " . mysqli_error($conexao));
    }

    $bindParams = "issis"; // String indicando tipos de dados
    for ($i = 1; $i <= 10; $i++) {
        $bindParams .= "s"; // Supondo que as etapas são strings
    }

    $values = array_merge([$stmt, $bindParams, $id_cliente_artista, $nome_producao, $arte, $tempo, $valorTotal], array_values($etapas));
    call_user_func_array('mysqli_stmt_bind_param', $values);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}


/*if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // receber e validar os dados do formulário
    $nome_producao = isset($_POST["nome_producao"]) ? $_POST["nome_producao"] : "";
    $tempo = isset($_POST["tempo"]) ? $_POST["tempo"] : "";
    $valorTotal = isset($_POST["valorTotal"]) ? $_POST["valorTotal"] : "";

    // validar
    if (empty($nome_producao) || empty($tempo) || empty($valorTotal)) {
        echo "Por favor, preencha todos os campos obrigatórios.";
    } else {
        //converter se precisar
        $nome_producao = mysqli_real_escape_string($conexao, $nome_producao);
        $tempo = (int) $tempo; 
        $valorTotal = (float) $valorTotal;

        $conexao = obterConexao();

        if ($conexao) {
            
            $query = "INSERT INTO ficha (nome_producao, tempo, valorTotal) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conexao, $query);
            mysqli_stmt_bind_param($stmt, "sis", $nome_producao, $tempo, $valorTotal);

            if (mysqli_stmt_execute($stmt)) {
                echo "Dados inseridos com sucesso.";
            } else {
                echo "Erro ao inserir dados no banco de dados.";
            }
            
            mysqli_close($conexao);
        } else {
            echo "Erro na conexão com o banco de dados!";
        }
    }
}
*/
?>