<?php
require("../include/cabecalho_logged.php");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Formulário cadastro</title>
    <link rel="stylesheet" type="text/css" href="../css/style_cadastre2.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="page-wrapper"></div>
<div class="page-wrapper"></div>
<div class="container">
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 390" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#0693e3"></stop><stop offset="95%" stop-color="#eb144c"></stop></linearGradient></defs><path d="M 0,400 C 0,400 0,80 0,80 C 87.51196172248802,68.03827751196172 175.02392344497605,56.07655502392344 284,55 C 392.97607655502395,53.92344497607656 523.4162679425838,63.73205741626796 604,73 C 684.5837320574162,82.26794258373204 715.3110047846889,90.99521531100477 813,87 C 910.6889952153111,83.00478468899523 1075.3397129186606,66.28708133971293 1191,63 C 1306.6602870813394,59.71291866028708 1373.3301435406697,69.85645933014354 1440,80 C 1440,80 1440,400 1440,400 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.265" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 200)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#0693e3"></stop><stop offset="95%" stop-color="#eb144c"></stop></linearGradient></defs><path d="M 0,400 C 0,400 0,160 0,160 C 74.42105263157896,172.61244019138758 148.84210526315792,185.22488038277513 245,184 C 341.1578947368421,182.77511961722487 459.0526315789473,167.71291866028707 549,160 C 638.9473684210527,152.28708133971293 700.9473684210527,151.92344497607655 811,146 C 921.0526315789473,140.07655502392345 1079.157894736842,128.5933014354067 1192,130 C 1304.842105263158,131.4066985645933 1372.421052631579,145.70334928229664 1440,160 C 1440,160 1440,400 1440,400 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.4" class="transition-all duration-300 ease-in-out delay-150 path-1" transform="rotate(-180 720 200)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#0693e3"></stop><stop offset="95%" stop-color="#eb144c"></stop></linearGradient></defs><path d="M 0,400 C 0,400 0,240 0,240 C 94.5263157894737,244.62200956937798 189.0526315789474,249.24401913875596 286,252 C 382.9473684210526,254.75598086124404 482.3157894736843,255.64593301435406 586,248 C 689.6842105263157,240.35406698564594 797.6842105263158,224.17224880382776 883,228 C 968.3157894736842,231.82775119617224 1030.9473684210527,255.66507177033492 1120,261 C 1209.0526315789473,266.3349282296651 1324.5263157894738,253.16746411483254 1440,240 C 1440,240 1440,400 1440,400 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.53" class="transition-all duration-300 ease-in-out delay-150 path-2" transform="rotate(-180 720 200)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#0693e3"></stop><stop offset="95%" stop-color="#eb144c"></stop></linearGradient></defs><path d="M 0,400 C 0,400 0,320 0,320 C 86.59330143540669,334.3062200956938 173.18660287081337,348.6124401913876 258,342 C 342.8133971291866,335.3875598086124 425.8468899521531,307.85645933014354 524,302 C 622.1531100478469,296.14354066985646 735.4258373205741,311.9617224880383 831,316 C 926.5741626794259,320.0382775119617 1004.4497607655503,312.2966507177033 1103,311 C 1201.5502392344497,309.7033492822967 1320.7751196172248,314.85167464114835 1440,320 C 1440,320 1440,400 1440,400 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-3" transform="rotate(-180 720 200)"></path></svg>
<div class="container">
<form action="script_transicao.php" method="post">
  <div class="aviso">
    <h3>Você está prestes a iniciar a <span>transição</span> para se tornar um <span>artista</span>. Você poderá comercializar suas artes, adicionar um portifólio de suas obras e editar suas informações.</h3>
    <p>Tem certeza de que deseja continuar?</p>
    <button type="submit" class="btn btn-custom-success btn-lg" name="iniciar_transicao">Iniciar Transição</button>
    <button type="button" class="btn btn-custom-danger btn-lg" onclick="window.location.href='perfil.php'">Voltar</button>
</div>
</form>
</div>
</div>
</div>
<script src="js/md5.js"></script>
<script src="js/exibir_senha.js"></script>
<script src="js/verificar_senha.js"></script>
<noscript>
  Seu navegador não suporta código em JavaScript
</noscript>
</body>
</html>