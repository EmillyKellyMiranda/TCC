CREATE TABLE chat1(
    id INT NOT null AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR (30) NOT null,
    mensagem TEXT NOT null
);