<?php

include("../database/funcoes.php");
include("../include/cabecalho_logged.php");


if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    echo($_SESSION["usuario_logado"]);
    
}

echo($_SESSION["usuario_id"]);

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/style_cadastre3.css" rel="stylesheet">
    <script src="js/cadastro_producao.js"></script>

    <style>
        #fundo_form {
            background-color: #000000;
            border-radius: 30px;
        }

        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            max-width: 850px;
            margin-top: 100px; /* Ajuste a margem superior conforme necessário */
            background-color: black;
            color: white;
            font-family: 'DELAQRUS', sans-serif;
        }
        .btn-custom {
            display: block;
            border-radius: 100px;
            width: 50px;
            height: 50px;
            color: #ffffff;
            background-color: #00ffda;
            border-color: #00ffda;
            transition: all 0.3s ease; /* para suavizar a transição */
            text-align: top;
        }
        .chat-container {
            display: flex;
            align-items: flex-start;
        }
        #section {
            margin-bottom: 50px;
            margin-left: 50px;
            margin-right: 800px;
            text-align: center;
        }
        #showFormButton {
            display: flex;
            justify-content: flex-start; /* Alinhe o botão à esquerda */
            margin-top: 20px; /* Ajuste a margem superior conforme necessário */
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 20px; /* Ajuste a margem superior conforme necessário */
        }
        .form-container {
            display: none;
            border-color: white;
            border-style: none;
            border-width: 9px;
            width: 100%;
            margin-left: 500px;
        }
        .card label {
    color: white; /* Define a cor do texto dos rótulos como branco */
}
#infoContainer {
    margin-top: 20px; /* Adicione a quantidade de margem que você deseja */
}
    </style>
</head>
<body>

<div class="page-wrapper"></div>
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 590" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,200 0,200 C 91.25358851674642,156.1531100478469 182.50717703349284,112.30622009569379 290,128 C 397.49282296650716,143.6937799043062 521.224880382775,218.92822966507174 616,244 C 710.775119617225,269.07177033492826 776.5933014354066,243.98086124401914 855,209 C 933.4066985645934,174.01913875598086 1024.4019138755982,129.14832535885165 1124,126 C 1223.5980861244018,122.85167464114834 1331.7990430622008,161.42583732057417 1440,200 C 1440,200 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.53" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 300)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,400 0,400 C 106.07655502392345,356.3062200956938 212.1531100478469,312.6124401913876 297,337 C 381.8468899521531,361.3875598086124 445.46411483253587,453.8564593301436 539,455 C 632.5358851674641,456.1435406698564 755.9904306220094,365.9617224880383 849,361 C 942.0095693779906,356.0382775119617 1004.5741626794259,436.29665071770336 1098,457 C 1191.4258373205741,477.70334928229664 1315.712918660287,438.8516746411483 1440,400 C 1440,400 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-1" transform="rotate(-180 720 300)"></path></svg>
   
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<div class="container">
<button id="showFormButton" style="margin-top: 100px" name="showFormButton" class="btn btn-custom-danger">Negociação</button>
    <div class="form-container" id="formContainer">
        <div class="card">
            <div class="card-body">
            <!-- Form -->
            <form id="fichaform" method="post" action="ficha.php"> 

                <!-- *****        recuperar o nome do cliente          *****-->

                <div class="mb-3">
                    <label for="nome_producao" class="form-label">Produção:</label>
                    <input type="text" class="form-control" id="nome_producao" name="nome_producao" placeholder="Exemplo: Quadro da família Alves">
                </div>

                <div class="mb-3">
                <!--                             VER ESSA PARTE DEPOIS
                <label class="etapas" for="tipo_arte"><strong>Tipo de arte:</strong></label>
                <select id="tipo_arte" name="tipo_arte" class="form-control">
                    <option id="animacao" value="Animação">Animação</option>
                    <option id="desenho" value="Desenho digital">Desenho digital</option>
                    <option id="desenho_fisico" value="Desenho físico">Desenho físico</option>
                    <option id="escultura" value="Escultura">Escultura</option>
                    <option id="pintura" value="Pintura">Pintura</option>
                </select>
                -->
                </div>

                <div class="mb-3">
                     <label for="tempo" class="form-label">Tempo:</label>
                    <input type="number" class="form-control" id="tempo" name="tempo" min="0" placeholder="---- dias">
                </div>

                <div id="etapasProducao" style="display:none;">
                    <div class="mb-3">
                        <label for="etapa1" class="form-label">Etapa de Produção 1:</label>
                        <input type="text" class="form-control" id="etapa1" name="etapa1" disabled>
                    </div>
                    <div class="mb-3">
                        <label for="etapa2" class="form-label">Etapa de Produção 2:</label>
                        <input type="text" class="form-control" id="etapa2" name="etapa2" disabled>
                    </div>
                    <div class="mb-3">
                        <label for="etapa3" class="form-label">Etapa de Produção 3:</label>
                        <input type="text" class="form-control" id="etapa3" name="etapa3" disabled>
                    </div>
                </div>

                <div class="mb-3">
                    <br>
                    <label for="valorTotal" class="form-label">Valor total:</label>
                    <input type="text" class="form-control" id="valorTotal" name="valorTotal" oninput="formatCurrency(this)" placeholder="R$" required>
                </div>
                <br>

                <button class="btn-custom-success btn-lg" type="submit">Registrar</button>
            </form>
            </div>
            </div>
            </div>
    
</div>

<div class="container">
<div style="margin-top: 80px;"> 
<div id="resultado"></div>
</div>
</div>

<script>

    /* pra fazer aparecer a ficha do lado */
    const showFormButton = document.getElementById("showFormButton");
    const formContainer = document.getElementById("formContainer");

    showFormButton.addEventListener("click", () => {
        formContainer.style.display = "block";
    });

    /** formulário */
    function formatCurrency(input) {
    const value = input.value.replace(/\D/g, ""); // Remove todos os caracteres não numéricos
    const formattedValue = (value / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    input.value = formattedValue;
}



/*
function showEtapas() {
    const tipoObra = document.getElementById("tipoObra").value;
    const etapasDiv = document.getElementById("etapasProducao");

    if (tipoObra === "selecione") {
        etapasDiv.style.display = "none";
    } else {
        // Fazer uma solicitação AJAX para obter as etapas de produção
        fetch("getEtapas.php", {
            method: "POST",
            body: new URLSearchParams({ tipoObra: tipoObra }),
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
        })
            .then((response) => response.json())
            .then((data) => {
                etapasDiv.style.display = "block";
                document.getElementById("etapa1").value = data.etapa1 || "";
                document.getElementById("etapa2").value = data.etapa2 || "";
                document.getElementById("etapa3").value = data.etapa3 || "";
            })
            .catch((error) => {
                console.error("Erro ao obter etapas de produção: " + error);
            });
    }
}
*/

</script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
