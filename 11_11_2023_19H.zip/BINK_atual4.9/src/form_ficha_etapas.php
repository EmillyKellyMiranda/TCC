<?php 
include("../database/funcoes.php");
    $var = $_GET['Parametro_arte'];
    $id_artista = $_GET['id_artista'];

 

    if ($var !== null) {   
        
        $conexao3 = obterConexao();
        $htmlEtapas = '';

        for($i=1; $i<11; $i++){

            $sql3 = "SELECT etapa$i FROM producao WHERE id_artista = ? AND arte = ?";
            $stmt3 = mysqli_prepare($conexao3, $sql3);
            mysqli_stmt_bind_param($stmt3, "is", $id_artista, $var);
            mysqli_stmt_execute($stmt3);
            $etapa = mysqli_stmt_get_result($stmt3);

            
            // Verifica se há resultados
            if($etapa !== null) {
                // Itera sobre os resultados
                while($linha = mysqli_fetch_assoc($etapa)) {
                    // $linha["etapa$i"] contém o valor da coluna específica
                    $etapaAtual = $linha["etapa$i"];
                    // Faça o que precisar com $etapaAtual
                    if($etapaAtual !== null){

                        $htmlEtapas .= "
                            <div class='mb-3'>
                                <label for='etapa[$i]' class='form-label'>Etapa de Produção $i:</label>
                                <input type='text' class='form-control' id='etapa[$i]' name='etapa[$i]' placeholder='$etapaAtual' disabled>
                            </div>";
                    }

                }
                
            } else {
                $htmlEtapas = "<p>Nenhum resultado encontrado.</p>";
            }
            mysqli_stmt_close($stmt3);
        }            
        
        mysqli_close($conexao3);
        echo $htmlEtapas;
    }else{

        echo"<p style='color:pink;'>Escolha um tipo de arte!!!</p>";
    }
?>

