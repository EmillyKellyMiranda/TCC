<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
<?php
ob_start();
session_start();
if (!isset($_SESSION["usuario_logado"])){
    header("Location: ../public/index.php");
}

    if (isset($_SESSION["usuario_logado"])){ ?>
        <div class="text-right">
            <h4 class="mt-5 text-success">Você está logado como <?= $_SESSION["usuario_logado"] ?></h4>
        <?php } ?>
    </div> 
</body>
</html>