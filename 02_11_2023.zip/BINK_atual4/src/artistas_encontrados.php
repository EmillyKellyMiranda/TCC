<?php
    session_start();
    include ("../include/cabecalho_logged.php");

    require("../database/funcoes.php");

    if (!isset($_SESSION["usuario_logado"])){
        header("Location: ../public/index.php");
    }

    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
?>


<!DOCTYPE html>
<html lang="pt">
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body{
            background-color: #000000;
        }

        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }
        
        .container {
            display: absolute;
            /*margin: 100px;
            float: left;*/
            justify-content: space-between;
            align-items: flex;
            margin-top: 200px; /* Ajuste a margem superior conforme necessário */
            color:#ffffff;
            width:600px;
            border: solid 1px;
            border-color: rgb(0, 255, 191); 
            
        }

        li{
            color:rgb(0, 255, 191);
        }

        
        .form-container {
            display: none;
            border-color: white;
            border-style: none;
            border-width: 9px;
            width: 100%;
            margin-left: 500px;
        }
        

        .center-both {
            display: flex;
            justify-content: center;
            height: 60vh;
            width:80vh;
            background:#e4ebe5;
            margin-top:500px;
        }
    </style>
</head>
<body>

        <div class="container">

            <?php
            $conexao = obterConexao();

            if (isset($_POST['nick'])) {
                $pesquisaUser = $_POST['nick']; 

                // Execute a consulta SQL para pesquisar artistas pelo "nick"
                $sql = "SELECT artista.id_artista, cliente.nick FROM artista
                        INNER JOIN cliente ON artista.id_cliente = cliente.id_cliente
                        WHERE cliente.nick LIKE '%$pesquisaUser'";

                $result = mysqli_query($conexao, $sql);

                if ($result) {
                    
                    if (mysqli_num_rows($result) > 0) {
                        echo "<h2>Artistas encontrados:</h2>";
                        while ($artista = mysqli_fetch_assoc($result)) {
                            $artistaId = $artista['id_artista'];
                            $artistaNick = $artista['nick'];?>

                                <h3><ul>
                                    <li><a style="color: rgb(0, 255, 191);" href='perfil2.php?id=<?php echo$artistaId;?>'><?php echo$artistaNick;?> </a></li>
                                </ul></h3><br>
                        <?php
                        }
                    } else {
                        echo "<h2>Nenhum artista encontrado com o nick: $pesquisaUser</h2>";
                    }
                } else {
                    echo "Erro na consulta: " . mysqli_error($conexao);
                }

                
                mysqli_close($conexao);
            }
            ?>
            
        </div>

    
    
</body>
</html>

