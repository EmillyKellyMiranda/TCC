<?php 
    session_start();
    include ("../include/cabecalho_logged.php");

    if (!isset($_SESSION["usuario_logado"])){
        header("Location: ../public/index.php");
    }

    require ("../database/funcoes.php");
    $id_selecionado =$_GET["id"];

    
    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);


    $conexao1 = obterConexao();
    $sql1 = "SELECT id_cliente FROM artista WHERE id_artista = ?";
    $stmt1 = mysqli_prepare($conexao1, $sql1);
    mysqli_stmt_bind_param($stmt1, "i", $id_selecionado);
    mysqli_stmt_execute($stmt1);
    $resultado = mysqli_stmt_get_result($stmt1);

    while ($row = mysqli_fetch_assoc($resultado)) {
        // $row conterá os dados da linha do resultado
        $id_user = $row['id_cliente'];
        // Faça o que quiser com $id_cliente
    }

   $user_selecionado = buscarUsuarioPorId($id_user);


?>
<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Página de Perfil</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../css/style_cabecalho_unlogged.css" />
        <script src="js/btn_curriculo.js"></script>
        <script src="js/uf_curriculo.js"></script>
            




        <!-- o style tá aqui porque tem algum problema colocando ele de forma externa, vou arrumar depois -->
        <style> 
            .modal2 {
                display: none;
                position: fixed;
                z-index: 5;
                left: 0;
                top: -75px;
                width: 100%;
                height: 100%;
                overflow: hidden; /* Alterado para "hidden" para desativar o scroll */
                background-color: rgba(0, 0, 0, 0.4);
            }

            /*.modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;*/
            /*text-align: left; /* Adicionado para alinhar à esquerda */
            /*display: flex;
            flex-direction: column;
            align-items: flex-start;
            border-top: 20px solid black; /* Adiciona borda preta no topo */
            /*}*/

            .button-container2 {
            display: flex;
            justify-content: center;
            margin-top:-20px;
            }
            .cancel-button2 {
            margin-left: 10px;
            
            }
            h4{
                margin-top: -80px;
            }
            body{
                margin:0;
            }
            body, html {
            height: 100%;
            margin: 0;
            position: relative;
            background-color: transparent;
            }
            .nomedoperfil{
                padding: 10px;
                border-radius:10px;
                color:black;
            }
            .container2{
            background-color: #00ffda;
            margin:0;
            }
            #btn-favoritar{
                border-color: #000000;
            }
            #btn-favoritar:hover{
                background-color: #00ffda;
                border-color: #00ffda;
            }
            .page-wrapper {
                background-color: #000000;
                position: absolute;
                top: 0;
                bottom: 0;
                left: 0;
                right: 0;
                z-index: -1;  
            }
            svg {
            position: absolute;
            top: 90px;
            left: 0;
            width: auto;
            height: auto;
            z-index: -1;
            }
            .svg2 {
            position: absolute;
            top: 30px;
            left: 0;
            width: auto;
            height: auto;
            z-index: -1;
            }
            .wave {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            z-index: -1;
            }
            .content {
            position: relative;
            z-index: 1;
            }
            .cancelar{
                color:white;
                background-color: #d8222f !important;
                margin-right:-200px;
            }
            .salvar{
                color:white;
                background-color: #000000 !important;
                margin-right:20px;
            }
            .salvar:hover{
                color:white;
                background-color: #00ffda !important;
                margin-right:20px;
            }
            ul{
                width:300px;
            }
            body {
                background-color:black;
            }
            .container{
                margin-top: 20px;
            }
            .card {
                background-color: #ffffff;
                margin-top:122px;
                
            }
            .card-body {
            z-index: 1;
                
            }
            .card-header {
                background-color: #000000;
                color: #ffffff;
                height:30px;
                z-index: 1;
            }
            .card-footer {
                background-color: #000000;
            }
            .btn-custom-danger {
                background-color: #000000 !important;
                color: #FFFFFF;
            }
            
            .btn-custom-danger:hover {
                background-color: #00ffda !important;
                color: #FFFFFF !important;
                border-color: #00ffda;
            }
            /*.btn-custom-primary{
                margin-left:20px;
                background-color: #000000;
                color: #FFFFFF;
                border-color: white;
            }*/
            /*.btn-custom-secondary{
                background-color: #000000;
                width: 40px;
                height: 34px;
                border-radius:12px;
                margin-top:-40px;
                margin-left: 135px;
                margin-bottom:30px;
                color: #FFFFFF;
                border-color: white;
            }*/
            .btn:hover {
                background-color: #00ffda;
                color: #000000;
            }
            
            .margem {
                margin-top: 5px;
            }
            .nomeuser{
                margin-top: 5px;
            }
            .modal-title{
                margin-left:20px;
            }
            .custom-file-label {
            text-align: left;
            }
            .botao2{
            margin-top:-50px;
            margin-left:0px;
            }
            /*.list-group-item{
                width:500px;
            }*/
            .checkbox-group {
            text-align: left;
            }
            .align-right {
            float: right;
            }
    </style>
    </head>
    <body>

      
        <div class="container mt-5">
        <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 590" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,200 0,200 C 91.25358851674642,156.1531100478469 182.50717703349284,112.30622009569379 290,128 C 397.49282296650716,143.6937799043062 521.224880382775,218.92822966507174 616,244 C 710.775119617225,269.07177033492826 776.5933014354066,243.98086124401914 855,209 C 933.4066985645934,174.01913875598086 1024.4019138755982,129.14832535885165 1124,126 C 1223.5980861244018,122.85167464114834 1331.7990430622008,161.42583732057417 1440,200 C 1440,200 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.53" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 300)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,400 0,400 C 106.07655502392345,356.3062200956938 212.1531100478469,312.6124401913876 297,337 C 381.8468899521531,361.3875598086124 445.46411483253587,453.8564593301436 539,455 C 632.5358851674641,456.1435406698564 755.9904306220094,365.9617224880383 849,361 C 942.0095693779906,356.0382775119617 1004.5741626794259,436.29665071770336 1098,457 C 1191.4258373205741,477.70334928229664 1315.712918660287,438.8516746411483 1440,400 C 1440,400 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-1" transform="rotate(-180 720 300)"></path></svg>
            <div class="row">
                <!--------------------------------------------------F-O-T-O---A-R-T-I-S-T-A----------------------------------------------------->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                        </div>
                        <div class="card-body text-center">
                            <div class="nomedoperfil">
                                <h4 class="nomeuser">@<?= $user_selecionado["nick"] ?></h4>
                                
                            </div>
                            <?php if ($user_selecionado["foto_perfil"]): ?>
                                <img src="<?= $user_selecionado["foto_perfil"] ?>" alt="Foto de perfil de <?= $user_selecionado["nome"] ?>" width="200px" height="200px"  class="margem rounded-circle mb-5 img-thumbnail profile-picture" >
                            <?php else: ?>
                                <img src="fotos/default.jpg" alt="Foto de perfil padrão" width="200px" height="200px" class="margem rounded-circle mb-5 img-thumbnail">
                            <?php endif; ?>
                        
                        </div>
                        <button type="button" id="btn-favoritar" class="btn btn-custom-danger" title="Favoritar"><i class="fas fa-heart"></i></button>
                    </div>
                </div>
                <!------------------------------------------------------------------------------------------------------------------------------>


                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3></h3>
                        </div>
                        <!-------------------------------------------I-N-F-O-R-M-A-C-A-O---D-O---A-R-T-I-S-T-A--------------------------------------------->
                        <div id="conteudo" name="conteudo"></div>
                            <?php if ($user_selecionado["is_artist"]): ?>
                                <?php include "curriculo.php"; ?>
                                <?php 
                                    $conexao2 = obterConexao();
                                    $sql = "SELECT localizacao, localizacao2, sobre_artista, formacao, estilo_arte, contato FROM curriculo WHERE id_artista = ?";
                                    $stmt = mysqli_prepare($conexao2, $sql);
                                    mysqli_stmt_bind_param($stmt, "i", $user_selecionado["id_cliente"]);
                                    mysqli_stmt_execute($stmt);
                                    $resultado = mysqli_stmt_get_result($stmt);
                                    $dados = mysqli_fetch_array($resultado);

                                    $localizacao = $dados[0] ?? "";
                                    $localizacao2 = $dados[1] ?? "";
                                    $sobre = $dados[2] ?? "";
                                    $formacao = $dados[3] ?? "";
                                    $estilo = $dados[4] ?? "";
                                    $contato = $dados[5] ?? "";
                                ?>
                                <h3>Informações do Artista:</h3>
                                <ul class="list-group">
                                    <?php if (!empty($localizacao) && !empty($localizacao2)): ?>
                                    <li class="list-group-item"><strong>Localização:</strong> <?= $localizacao ?>, <?= $localizacao2 ?></li>
                                    <?php endif; ?>
                                    <?php if (!empty($sobre)): ?>
                                    <li class="list-group-item"><strong>Sobre o Artista:</strong> <?= $sobre ?></li>
                                    <?php endif; ?>
                                    <?php if (!empty($formacao)): ?>
                                    <li class="list-group-item"><strong>Formação:</strong> <?= $formacao ?></li>
                                    <?php endif; ?>
                                    <?php if (!empty($estilo)): ?>
                                    <li class="list-group-item"><strong>Estilo de Arte:</strong> <?= $estilo ?></li>
                                    <?php endif; ?>
                                    <?php if (!empty($contato)): ?>
                                    <li class="list-group-item"><strong>Contato:</strong> <?= $contato ?></li>
                                    <?php endif; ?>
                                </ul>
                                <br>
                            <?php endif; ?>
                            
                            
                            <div><button id="btn_add_contato" name="btn_curriculo" class="btn btn-custom-danger" style=""  onclick="addContato()">Adicionar contato</button></div>
                          
                            <?php
                                function addContato(){
                                    $conexao3 = obterConexao();

                                    $sql3 = "SELECT id_cliente, id_addContato FROM contatos WHERE id_cliente = {$usuario['id_cliente']} AND id_addContato = {$user_selecionado['id_cliente']}";
                                    $stmt3 = mysqli_prepare($conexao3, $sql3);
                                    mysqli_stmt_bind_param($stmt3, "i", $user_selecionado["id_cliente"]);
                                    mysqli_stmt_execute($stmt3);
                                    $resultado = mysqli_stmt_get_result($stmt3);
                                    $num_linhas = mysqli_num_rows($resultado);

                                    if($num_linhas>0){
                                        //depois precisa tratar essa possibilidade adequadamente
                                        //mudando o texto do botão para "excluir usuário" e 
                                        //fazendo com que se cair nesse if ele exclua o user dos contatos.
                                        echo"ESSE USUÁRIO JÁ FOI ADICIONADO AOS CONTATOS";
                                        mysqli_stmt_close($stmt3);
                                        mysqli_close($conexao3);


                                    }else{
                                        $sql4 = "INSERT INTO contatos (id_cliente, id_addContato, nome_addContato) VALUES (?, ?, ?)";
                                        $stmt4 = mysqli_prepare($conexao3, $sql4);
                                        mysqli_stmt_bind_param($stmt4, "iis", $usuario["id_cliente"], $user_selecionado["id_cliente"], $user_selecionado["nick"]);
                                        mysqli_stmt_execute($stmt4);
                                        mysqli_stmt_close($stmt4);
                                        mysqli_close($conexao3);

                                    }
                                    

                                }
                                        
                            
                            ?>
                            <br/>
                        </div>
                        <!--------------------------------------------------------------------------------------------------------------------------------->
                        
                    </div><br/>    

                </div>



            </div>
        </div>    
        <div class="card-footer">
        <small class="text-muted"></small>
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.16.6/dist/umd/popper.min.js" integrity="sha384-mRl5x5AjzDtw5wYQO4O4BjKq3ZD9hh6RH/U6j0G6xNuI7N/wzYc0F/Kd/PuHlXZF" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
