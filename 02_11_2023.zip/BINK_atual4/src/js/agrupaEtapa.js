"use strict"; 
window.onload = function() { 
    $(document).ready(function() {
        // elements esta recebendo todos os elementos que são da classe agrupa3
        var elements = $(".agrupa3"); /* $() ou jQuery() = função do jQuery que permite selecionar elementos, 
                                        criar e lidar com o carregamento do DOM de maneira eficaz. 
                                        Ela é usada para simplificar a interação com elementos HTML em páginas da web.*/

        var elementosPorContainer = 3;
        var contador = 0;

        var container = $("<div class='container'></div>");

        // Percorre todos os elementos com a classe "agrupa3"
        elements.each(function(index) {
            // Adiciona o elemento atual ao contêiner
            container.append($(this));
            contador++;

            // Se o contador atingir o limite ou for o último elemento
            if (contador === elementosPorContainer || index === elements.length - 1) {
                // Adiciona o contêiner ao body
                container.appendTo("body"); 

                // Reinicia o contador e cria um novo contêiner?
                contador = 0;
                container = $("<div class='container'></div>");
            }
        });
    });
}    