"use strict";
window.onload = function() {
    function apagarOption(tipo_arte) {
        var pegaArte = tipo_arte;
        var elemento = document.getElementById(pegaArte);
        elemento.style.display = "none";
        
    }
}