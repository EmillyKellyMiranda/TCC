<?php 
    session_start();
    include ("../include/cabecalho_logged.php");

    if (!isset($_SESSION["usuario_logado"])){
        header("Location: ../public/index.php");
    }

    require ("../database/funcoes.php");
    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
?>




<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Página de Perfil</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../css/style_cabecalho_unlogged.css" />
        <script src="js/chat.js"></script>
        <style>
            .center-both {
                display: flex;
                justify-content: center;
                height: 60vh;
                width:80vh;
                background:#e4ebe5;
                margin-top: 25vh;
            }
            .card-body{
                margin-top: none;
            }
        </style>  
    </head>




    <body>    
        <?php
        /*------------------------------------------R-E-C-E-B-E---N-O-M-E-S----------------------------------------------------------------*/ 
            $conexao = obterConexao();
            $sql = "SELECT nome FROM cliente";
            $stmt = mysqli_prepare($conexao, $sql);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $nomes);
            
            //cria um array
            $nomes_array = array();

            //faz um laço que se repere ate as linhas $stmt nao forem true
            while (mysqli_stmt_fetch($stmt)) {
                //crio uma nova var 
                $resultado = array(
                    "nome" => $nomes
                );
                //coloco no meu array inicial os nomes encontrados
                $nomes_array[] = $resultado;
            }
         /*---------------------------------------------------------------------------------------------------------------------------------*/     
        ?>
    

        <div class="container-sm center-both">
            <div class="card-body text-rigth" >

                <div id="recebeM">
                    

                    <?php 
                    /*------------------------------------------M-O-S-T-R-A---N-O-M-E-S-----------------------------------------------------*/ 

                     foreach ($nomes_array as $resultado) {
                        $nomeUser = $resultado["nome"];
                        $sql2 = "SELECT id_cliente FROM cliente WHERE nome=?";
                        $stmt2 = mysqli_prepare($conexao, $sql2);
                        mysqli_stmt_bind_param($stmt2, "s", $nomeUser);
                        mysqli_stmt_execute($stmt2);
                        $resultade = mysqli_stmt_bind_result($stmt2, $id_user);
                        // Armazenar $id_user em um array
                        $id_user_array = array();
                        while (mysqli_stmt_fetch($stmt2)) {
                            $id_user_array[] = $id_user;
                        }

                        // Loop para exibir cada valor de $id_user
                        foreach ($id_user_array as $id_user) {
                            echo "<p> <a id='" . $id_user . "' href='chat2.php' class='user-link'>" . $nomeUser . "," . $id_user . "</a></p><br>";
                            $_SESSION["id_user"]=$id_user;

                        }

                        // Fechar a consulta preparada após processar os resultados
                        mysqli_stmt_close($stmt2);
                    }
                    /*----------------------------------------------------------------------------------------------------------------------*/ 

                    ?>
                    </a>
                </div>

            </div>    
        </div>
                
        






        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.16.6/dist/umd/popper.min.js" integrity="sha384-mRl5x5AjzDtw5wYQO4O4BjKq3ZD9hh6RH/U6j0G6xNuI7N/wzYc0F/Kd/PuHlXZF" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>