<?php
    require_once ("conecta_bd.php");

    function mostrarTipoArte(){
        $mostrar_tipoarte = [];
        $sql = "SELECT * FROM tipo_arte";

        $conexao = obterConexao();    
        $stmt = $conexao->prepare($sql);
        $stmt->execute();
        $resultado_tipoarte = $stmt->get_result();
        while ($tipoarte = mysqli_fetch_assoc($resultado_tipoarte)){
            array_push($mostrar_tipoarte, $tipoarte);
        }
        $stmt->close();
        $conexao->close();

        return $mostrar_tipoarte;
    }
?>