<?php

include("../database/funcoes.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit();
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

$nome_producao = isset($usuario["nome_producao"]) ? $usuario["nome_producao"] : "";
$tempo = isset($usuario["tempo"]) ? $usuario["tempo"] : "";
$valorTotal = isset($usuario["valorTotal"]) ? $usuario["valorTotal"] : "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $nome_producao = isset($_POST["nome_producao"]) ? $_POST["nome_producao"] : "";
    $tempo = isset($_POST["tempo"]) ? $_POST["tempo"] : "";
    $valorTotal = isset($_POST["valorTotal"]) ? $_POST["valorTotal"] : "";

    $conexao = obterConexao();

    if ($conexao) {
        cadastrarFicha($usuario["id_cliente"], $nome_producao, $tempo, $valorTotal);
        mysqli_close($conexao);

        header("Location: imprime_ficha.php");
        exit();
    } else {
        echo "Erro na conexão com o banco de dados!";
    }
}

function cadastrarFicha($id_cliente, $nome_producao, $tempo, $valorTotal) {
    $conexao = obterConexao();
    $sql = "INSERT INTO ficha (id_artista, nome_producao, tempo, valorTotal) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "isis", $id_cliente, $nome_producao, $tempo, $valorTotal);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conexao);
}



/*if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // receber e validar os dados do formulário
    $nome_producao = isset($_POST["nome_producao"]) ? $_POST["nome_producao"] : "";
    $tempo = isset($_POST["tempo"]) ? $_POST["tempo"] : "";
    $valorTotal = isset($_POST["valorTotal"]) ? $_POST["valorTotal"] : "";

    // validar
    if (empty($nome_producao) || empty($tempo) || empty($valorTotal)) {
        echo "Por favor, preencha todos os campos obrigatórios.";
    } else {
        //converter se precisar
        $nome_producao = mysqli_real_escape_string($conexao, $nome_producao);
        $tempo = (int) $tempo; 
        $valorTotal = (float) $valorTotal;

        $conexao = obterConexao();

        if ($conexao) {
            
            $query = "INSERT INTO ficha (nome_producao, tempo, valorTotal) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conexao, $query);
            mysqli_stmt_bind_param($stmt, "sis", $nome_producao, $tempo, $valorTotal);

            if (mysqli_stmt_execute($stmt)) {
                echo "Dados inseridos com sucesso.";
            } else {
                echo "Erro ao inserir dados no banco de dados.";
            }
            
            mysqli_close($conexao);
        } else {
            echo "Erro na conexão com o banco de dados!";
        }
    }
}
*/
?>