<?php
include("../database/funcoes.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit();
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
$conexao = obterConexao();

if (!$conexao) {
    echo "Erro na conexão com o banco de dados!";
    exit();
}

$fichas = obterDadosFicha($usuario["id_cliente"]);
mysqli_close($conexao);


foreach ($fichas as $ficha) {
    echo "Nome da Produção: " . $ficha["nome_producao"] . "<br>";
    echo "Tempo: " . $ficha["tempo"] . " dias<br>";
    echo "Valor Total: R$ " . number_format($ficha["valorTotal"], 2, ',', '.') . "<br><br>";
}

function obterDadosFicha($id_cliente) {
    $conexao = obterConexao();

    $sql = "SELECT nome_producao, tempo, valorTotal FROM ficha WHERE id_artista = ?";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_cliente);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $nome_producao, $tempo, $valorTotal);

    $fichas = [];
    while (mysqli_stmt_fetch($stmt)) {
        $fichas[] = [
            "nome_producao" => $nome_producao,
            "tempo" => $tempo,
            "valorTotal" => $valorTotal
        ];
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conexao);

    return $fichas;
}


/*
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php include "ficha.php"; ?>
  <?php 
    $conexao = obterConexao();
    $sql = "SELECT nome_producao, tempo, valorTotal FROM ficha WHERE id_producao_ficha = ?";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "i", $_SESSION["usuario_id"]);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $dados = mysqli_fetch_array($resultado);

    $nome_producao = $dados[0] ?? "";
    $tempo = $dados[1] ?? "";
    $valorTotal = $dados[2] ?? "";
  ?>
   <div class="form-container" id="infoContainer"> <!-- Container para informações da ficha -->
    <div class="card">
      <div class="card-body">
        <h3>Ficha:</h3>
        <ul class="list-group">
          <?php if (!empty($nome_producao)): ?>
            <li class="list-group-item"><strong>Produção:</strong> <?= $nome_producao ?></li>
          <?php endif; ?>
          <?php if (!empty($tempo)): ?>
            <li class="list-group-item"><strong>Tempo:</strong> <?= $tempo ?></li>
          <?php endif; ?>
          <?php if (!empty($valorTotal)): ?>
            <li class="list-group-item"><strong>Valor Total:</strong> <?= $valorTotal ?></li>
          <?php endif; ?>
        </ul>
        <br>
      </div>
    </div>
  </div>
</body>
</html>
*/?>