<?php
    include ("../include/cabecalho_logged.php");
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <title>perfil </title>
    <style>
        .btn-primary{
            
        }
    </style>
    </head>

    <body>


        <div id="curriculo">
            <input id="btn_curriculo" type="button" class="btn btn-primary" value="btn">
        </div> 

        <div id="form_curriculo">

            <p id="conteudo"></p>

            <?php
                /*
                fazer uma consulta para recuperar o curriculo daquele cliente (count=0)
                se a quantidade de registros/valores for 0 ele está vazio
                    formatar os campos do formulário em branco
                senão
                    com os dados da consulta, preencher o formulario*/

                //apos mostrar o form fazemos insercoes...
                require ("../database/funcoes.php");
                $usuario =buscarUsuarioPorId($_SESSION["usuario_id"]);
                
                $localizacao = $_POST["localizacao"];
                $sobre_artista = $_POST["sobre_artista"];
                $formacao = $_POST["formacao"];
                $estilo_arte = $_POST["estilo_arte"];
                $contato= $_POST["contato"];

                //conectando com o banco:
                require "../database/conecta_bd.php";
                $conexao = obterConexao();

                if($conexao){

                    $sql0 = "SELECT*from curriculo WHERE id_artistas";
                    $stmt0 = mysqli_prepare($conexao, $sql0);
                    $executou0 = mysqli_stmt_execute($stmt0);
                    $resultado0 = mysqli_stmt_get_result($stmt0);


                    //confere se o user ja registrou seu curriculo
                    if($artista == $resultado0 ){
                        $sql1 = "UPDATE curriculo 
                        SET localizacao='$localizacao', sobre_artista='$sobre_artista', formacao='$formacao', estilo_arte='$estilo_arte', contato='$contato')
                        WHERE id_artista='$usuario'";
                    }else{
                        $sql2 = "INSERT INTO curriculo (localizacao, sobre_artista, formacao, estilo_arte, contato)
                        values ('$localizacao', '$sobre_artista', '$formacao', '$estilo_arte', '$contato');";
                                                
                        $stmt2 = mysqli_prepare($conexao, $sql2);/*vinculando o comando sql e o banco*/
                        $executou2 = mysqli_stmt_execute($stmt2);/*executa a query/executa a solicitacao*/
                    }


                    
                }else{
                    echo('Erro na conexão!');
                }
                
            ?>
        </div>
        


        <!--ESTAMOS VINCULANDO O CODIGO A UM JS EXTERNO---> 
        <script src="js/btn_curriculo.js"></script>
        <noscript>
            Seu navegador não suporta código em JavaScript!
        </noscript>
         
    </body>

</html>