<?php
    function Conexao(){

        $servidor = "localhost";
        $usuario = "web";
        $senha = "web";
        $banco = "chat";

        $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);

        if (!$conexao){
            echo "A conexão não pôde ser estabelecida. Erro: " . mysqli_connect_error();
            die();  
        }
        return $conexao;
    }
?>
