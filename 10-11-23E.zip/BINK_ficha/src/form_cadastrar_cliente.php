<?php
require("../include/cabecalho_cadastro.php");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Formulário cadastro</title>
    <link rel="stylesheet" type="text/css" href="../css/style_cadastre.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="page-wrapper"></div>
<div class="container">
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><path d="M 0,700 C 0,700 0,350 0,350 C 219.5,303 439,256 679,256 C 919,256 1179.5,303 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="#000000" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path></svg>
  <h3>Faça o <span>cadastro</span> para começar a <p>explorar nossa plataforma!</p></h3>
  <div class="form-container">
  <form action="cadastrar_cliente.php" method="POST" class="formulario">
    <div class="row">
        <div class="col-md-6">
            <label for="nome" class="nome">Nome Completo:</label>
            <input class="form-control input-pequeno " type="text" name="nome" id="nome" minlength="3" maxlength="50" required oninput="this.value = this.value.replace(/[^a-zA-ZÀ-ú\s]/g, '')"/>
        </div>
        <div class="col-md-6">
            <label for="nick" class="nick ml-3">Nome de Usuário:</label>
            <input class="form-control input-pequeno ml-3" type="text" name="nick" id="nick" minlength="4" maxlength="16" required/>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <label for="email" class="email">E-mail:</label>
            <input class="form-control input-grande" type="email" name="email" id="email" required/>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <label for="data_nascimento" class="data">Data de nascimento:</label>
            <input class="form-control input-pequeno" type="date" name="data_nascimento" id="data_nascimento" onchange="validarIdade()" required/>
        </div>
        <div class="col-md-6">
            <label for="cpf" class="cpf ml-3">CPF:</label>
            <input class="form-control input-pequeno ml-3" type="text" name="cpf" id="cpf" placeholder="xxxxxxxxxxx" minlength="11" maxlength="11" pattern="[0-9]{11}" inputmode="numeric" oninput="this.value = this.value.replace(/[^0-9]/g, '')" required/>
        </div>
    </div>
    <div class="row">
    <div class="col-md-6">
    <label for="senha" class="senha">Senha:</label>
        <div class="input-group">
            <input class="form-control input-pequeno " type="password" name="senha" id="id_senha" pattern="^(?=.*[a-z])(?=.*[A-Z]).{8,}$" title="Mínimo 8 caracteres; Pelo menos uma letra maiscula e miniscula." required/>
            <div class="input-group-append">
            <span class="input-group-text"><i id="icon-eye" class="fas fa-eye-slash "></i></span>
        </div>
    </div>
</div>
    <div class="col-md-6">
        <label for="confirmar_senha" class="senha ml-3">Confirmar senha:</label>
        <div class="input-group">
            <input class="form-control input-pequeno ml-3" type="password" name="confirmar_senha" id="confirmar_senha" required/>
            <div class="input-group-append">
                <span class="input-group-text"><i id="icon-eye2" class="fas fa-eye-slash"></i></span>
            </div>
        </div>
    </div>
    </div>
    <button type="submit" class="btn btn-custom-success">Cadastrar</button>
</form>


<script>
    function validarIdade() {
        var dataNascimento = document.getElementById("data_nascimento").value;
        var dataAtual = new Date();
        var dataMinima = new Date(dataAtual.getFullYear() - 16, dataAtual.getMonth(), dataAtual.getDate());
        var data = new Date(dataNascimento);
        if (data > dataMinima) {
            document.getElementById("data_nascimento").setCustomValidity("Você precisa ter pelo menos 16 anos para se cadastrar.");
        } else {
            document.getElementById("data_nascimento").setCustomValidity("");
        }
    }
</script>
<script>
$(document).ready(function () {
    $('form').on('submit', function (e) {
        e.preventDefault();

        $.ajax({
            type: 'post',
            url: 'cadastrar_cliente.php',
            data: $('form').serialize(),
            success: function (response) {
                var jsonResponse = JSON.parse(response);

                if (jsonResponse.sucesso) {
                    // Mostra uma mensagem de sucesso
                    alert("Conta criada com sucesso!");

                    // Redireciona o usuário para index.php
                    window.location.href = '../public/index.php';
                } else {
                    // Mostra a mensagem de erro
                    alert(jsonResponse.erro);
                }
            }
        });
    });
});
</script>

<script>
  
  // Validar a confirmação da senha
  const senhaInput = document.getElementById('id_senha');
  const confirmarSenhaInput = document.getElementById('confirmar_senha');
confirmarSenhaInput.addEventListener('input', () => {
if (senhaInput.value !== confirmarSenhaInput.value) {
confirmarSenhaInput.setCustomValidity('As senhas não correspondem');
} else {
confirmarSenhaInput.setCustomValidity('');
}
});
</script>

<script>
 
const iconEye1 = document.querySelector('#icon-eye');
const inputPassword1 = document.querySelector('#id_senha');
const iconEye2 = document.querySelector('#icon-eye2');
const inputPassword2 = document.querySelector('#confirmar_senha');


iconEye1.addEventListener('click', function() {
  // Verifica o tipo do input
  if (inputPassword1.type === 'password') {
    // Altera o tipo para "text"
    inputPassword1.type = 'text';


    iconEye1.classList.remove('fa-eye-slash');
    iconEye1.classList.add('fa-eye');
  } else {

    inputPassword1.type = 'password';


    iconEye1.classList.remove('fa-eye');
    iconEye1.classList.add('fa-eye-slash');
  }
});


iconEye2.addEventListener('click', function() {
 
  if (inputPassword2.type === 'password') {
    
    inputPassword2.type = 'text';

    
    iconEye2.classList.remove('fa-eye-slash');
    iconEye2.classList.add('fa-eye');
  } else {
   
    inputPassword2.type = 'password';


    iconEye2.classList.remove('fa-eye');
    iconEye2.classList.add('fa-eye-slash');
  }
});
  
  document.getElementById("form").addEventListener("submit", validarSenha);
</script>
<script src="js/md5.js"></script>
<script src="js/exibir_senha.js"></script>
<script src="js/verificar_senha.js"></script>
<noscript>
  Seu navegador não suporta código em JavaScript
</noscript>
</body>
</html>