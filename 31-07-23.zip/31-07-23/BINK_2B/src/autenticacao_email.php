<?php
// Informações de login do servidor SMTP
$smtp_server = 'smtp.gmail.com';
$smtp_port = 587;
$smtp_username = 'bink@example.com';
$smtp_password = 'sua_senha';

// Informações do email
$from_email = 'seu_email@example.com';
$to_email = 'destinatario@example.com';
$subject = 'Assunto do email';
$message = 'Mensagem do email';

// Cria o cabeçalho do email com as informações de autenticação
$headers = array(
    'From' => $from_email,
    'To' => $to_email,
    'Subject' => $subject,
    'X-Mailer' => 'PHP/' . phpversion()
);
$headers_string = '';

foreach ($headers as $key => $value) {
    $headers_string .= $key . ': ' . $value . "\r\n";
}

// Cria a conexão com o servidor SMTP e faz a autenticação
$smtp_connection = fsockopen($smtp_server, $smtp_port, $errno, $errstr, 30);

if (!$smtp_connection) {
    echo "Erro ao conectar ao servidor SMTP: $errno $errstr";
    exit;
}

fputs($smtp_connection, "EHLO localhost\r\n");
fputs($smtp_connection, "STARTTLS\r\n");
fputs($smtp_connection, "AUTH LOGIN\r\n");
fputs($smtp_connection, base64_encode($smtp_username) . "\r\n");
fputs($smtp_connection, base64_encode($smtp_password) . "\r\n");

// Envia o email autenticado
fputs($smtp_connection, "MAIL FROM: $from_email\r\n");
fputs($smtp_connection, "RCPT TO: $to_email\r\n");
fputs($smtp_connection, "DATA\r\n");
fputs($smtp_connection, $headers_string . "\r\n" . $message . "\r\n.\r\n");
fputs($smtp_connection, "QUIT\r\n");

// Fecha a conexão com o servidor SMTP
fclose($smtp_connection);
?>
