<?php
require("../database/funcoes.php");

$nome = $_POST["nome"];
$nick = $_POST["nick"];
$data_nascimento = $_POST["data_nascimento"];
$cpf = $_POST["cpf"];
$email = $_POST["email"];
$senha = $_POST["senha"];

$erro_email = "";
$erro_cpf = "";
$erro_nick = "";

$conexao = obterConexao();

// Verifica se o e-mail já foi cadastrado
$query = "SELECT email FROM cliente WHERE email = '$email'";
$resultado = mysqli_query($conexao, $query);

if (mysqli_num_rows($resultado) > 0) {
    $erro_email = "Este e-mail já foi cadastrado. Tente novamente com outro e-mail.";
} else {
    // Verifica se o CPF já foi cadastrado
    $query = "SELECT cpf FROM cliente WHERE cpf = '$cpf'";
    $resultado = mysqli_query($conexao, $query);

    if (mysqli_num_rows($resultado) > 0) {
        $erro_cpf = "Este CPF já foi cadastrado. Tente novamente com outro CPF.";
    } else {
        // Verifica se o nick já foi cadastrado
        $query = "SELECT nick FROM cliente WHERE nick = '$nick'";
        $resultado = mysqli_query($conexao, $query);

        if (mysqli_num_rows($resultado) > 0) {
            $erro_nick = "Este nome de usuário já foi cadastrado. Tente novamente com outro nome de usuário.";
        } else {
            $response = cadastrarCliente($nome, $nick, $data_nascimento, $cpf, $email, $senha);
            if($response == true){
                $response = array("sucesso" => "Conta criada com sucesso!");
                echo json_encode($response);
                exit;
            } else {
                $erro_registro = "Ocorreu um erro com o cadastro, verifique suas credenciais e tente novamente.";
            }
        }
    }
}

mysqli_close($conexao);

$response = array("erro" => $erro_email . $erro_cpf . $erro_nick . (isset($erro_registro) ? $erro_registro : ""));
echo json_encode($response);
?>
