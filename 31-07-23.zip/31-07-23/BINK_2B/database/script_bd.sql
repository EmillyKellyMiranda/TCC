<?php
    require("../database/funcoes.php");

    session_start();
    
    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
    
    $localizacao = isset($_POST["localizacao"]) ? $_POST["localizacao"] : $usuario["localizacao"];
    $sobre_artista = isset($_POST["sobre_artista"]) ? $_POST["sobre_artista"] : $usuario["sobre_artista"];
    $formacao = isset($_POST["formacao"]) ? $_POST["formacao"] : $usuario["formacao"];
    $estilo_arte = isset($_POST["estilo_arte"]) ? $_POST["estilo_arte"] : $usuario["estilo_arte"];
    $contato = isset($_POST["contato"]) ? $_POST["contato"] : $usuario["contato"];
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $conexao = obterConexao();
        
        if ($conexao) {
            $sql = "SELECT COUNT(id_artista) AS total FROM curriculo WHERE id_artista = ?";
            $stmt = mysqli_prepare($conexao, $sql);
            mysqli_stmt_bind_param($stmt, "i", $usuario["id_cliente"]);
            mysqli_stmt_execute($stmt);
            $resultado = mysqli_stmt_get_result($stmt);
            $linha = mysqli_fetch_assoc($resultado);
            
            if ($linha["total"] == 0) {
                $sql = "INSERT INTO curriculo (id_artista, localizacao, sobre_artista, formacao, estilo_arte, contato)
                        VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($conexao, $sql);
                mysqli_stmt_bind_param($stmt, "isssss", $usuario["id_cliente"], $localizacao, $sobre_artista, $formacao, $estilo_arte, $contato);
                mysqli_stmt_execute($stmt);
            } else {
                $sql = "UPDATE curriculo SET localizacao = ?, sobre_artista = ?, formacao = ?, estilo_arte = ?, contato = ?
                        WHERE id_artista = ?";
                $stmt = mysqli_prepare($conexao, $sql);
                mysqli_stmt_bind_param($stmt, "sssssi", $localizacao, $sobre_artista, $formacao, $estilo_arte, $contato, $usuario["id_cliente"]);
                mysqli_stmt_execute($stmt);
            }
            
            mysqli_stmt_close($stmt);
            mysqli_close($conexao);
        } else {
            echo "Erro na conexão com o banco de dados!";
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Curriculo</title>
</head>
<body>
    <form method="POST" action="curriculo.php">
        <label for="localizacao">Localização:</label>
        <input type="text" id="localizacao" name="localizacao" value="<?= $localizacao ?>">
        <br>
        <label for="sobre_artista">Sobre o artista:</label>
        <textarea id="sobre_artista" name="sobre_artista"><?= $sobre_artista ?></textarea>
        <br>
        <label for="formacao">Formação:</label>
        <input type="text" id="formacao" name="formacao" value="<?= $formacao ?>">
        <br>
        <label for="estilo_arte">Estilo de arte:</label>
        <input type="text" id="estilo_arte" name="estilo_arte" value="<?= $estilo_arte ?>">
        <br>
        <label for="contato">Contato:</label>
        <input type="text" id="contato" name="contato" value="<?= $contato ?>">
        <br>
        <input type="submit" value="Salvar">
    </form>
</body>
</html>
