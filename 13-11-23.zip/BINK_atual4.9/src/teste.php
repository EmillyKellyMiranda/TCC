<!DOCTYPE html>
<html lang="pt">

    <head>

        <meta charset="UTF-8">
        <title>TITULO</title>

    </head>
    <body>

        <!--lugar onde vai ser adicionado o texto-->
        <output></output>
        <input type="text">


        <script>
            //abre a conexao com o servidor WebSocket
            const ws = new WebSocket('ws://8080')
            // atribui a acao a tecla enter
            const input = document.querySelector('input');
            const output = document.querySelector('output');

            ws.addEventListener('open', console.log);
            ws.addEventListener('message', console.log);

            //indica que recebeu a mensagem e vai fazer alguma coisa 
            ws.addEventListener('message', message => {
                //ao pegar os dados da mensagem ela está em JSON
                const dados = JSON.parse(message.data);

                if(dados.type ==='chat'){
                    output.append('Outro:' + dados.text, document.creatElement('br'))
                }

            });

            input.addEventListener('keypress', e =>{
                if(e.code == 'Enter'){
                    const valor = input.value;
                    //envia a mensagem
                    ws.send(valor);
                    //mostra o valor na tela 
                    output.append('eu:' + valor, document.creatElement('br'));
                    ws.send(valor);

                    //limpa o valor antigo do input 
                    input.velue = '';
                }

            });

        </script>
    </body>

</html>