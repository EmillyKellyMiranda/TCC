<?php
session_start();
include("../include/cabecalho_logged.php");
require("../database/funcoes.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
$meu_id = $usuario['id_cliente'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $status = isset($_POST["status"]) ? intval($_POST["status"]) : null;

    if ($status !== null) {
        if ($status === 0) {
            // Adicionar o contato
            $sql_cadastra = "INSERT INTO contatos (id_cliente, id_addContato, nome_addContato, btn_status) VALUES (?, ?, ?, ?)";
            $stmt_cadastra = mysqli_prepare($conexao, $sql_cadastra);
            mysqli_stmt_bind_param($stmt_cadastra, "iisi", $meu_id, $id_selecionado, $array_selecionado['nick'], $status);
            mysqli_stmt_execute($stmt_cadastra);
            echo "Contato adicionado com sucesso!";
        } else {
            // Remover o contato
            $sql_exclui = "DELETE FROM contatos WHERE id_cliente = ? AND id_addContato = ? AND nome_addContato = ? AND btn_status = ?";
            $stmt_exclui = mysqli_prepare($conexao, $sql_exclui);
            mysqli_stmt_bind_param($stmt_exclui, "iisi", $meu_id, $id_selecionado, $array_selecionado['nick'], $status);
            mysqli_stmt_execute($stmt_exclui);
            echo "Contato removido com sucesso!";
        }
    } else {
        echo "Erro: O status é nulo.";
    }
}
?>
