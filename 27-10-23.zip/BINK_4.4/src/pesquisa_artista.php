<?php
include "../database/conecta_bd.php"; 

if (isset($_GET['search'])) {
    $searchTerm = $_GET['search']; 

    
    $conexao = obterConexao();

    // Execute a consulta SQL para pesquisar artistas pelo "nick"
    $sql = "SELECT artista.id_artista, cliente.nick FROM artista
            INNER JOIN cliente ON artista.id_cliente = cliente.id_cliente
            WHERE cliente.nick LIKE '%$searchTerm'";

    $result = mysqli_query($conexao, $sql);

    if ($result) {
        
        if (mysqli_num_rows($result) > 0) {
            echo "<h2>Artistas encontrados:</h2>";
            while ($artista = mysqli_fetch_assoc($result)) {
                $artistaId = $artista['id_artista'];
                $artistaNick = $artista['nick'];

                // hiperlinks para as páginas de perfil dos artistas
                echo "<a href='artistas_encontrados.php?id=$artistaId'>$artistaNick</a><br>";

                // Adicione mais informações 
                echo "<br>";
            }
        } else {
            echo "Nenhum artista encontrado com o nick: $searchTerm";
        }
    } else {
        echo "Erro na consulta: " . mysqli_error($conexao);
    }

    
    mysqli_close($conexao);
}
?>
