<?php
    include ("../include/cabecalho_unlogged.php");
?>


<!DOCTYPE html>
<html lang="pt">
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/style_cadastre3.css" rel="stylesheet">

    <style>
        #fundo_form {
            background-color: #000000;
            border-radius: 30px;
        }
        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }
        .btn-custom {
            display: block;
            margin-top: 20px;
            border-radius: 100px;
            width: 50px;
            height: 50px;
            color: #ffffff;
            background-color: #00ffda;
            border-color: #00ffda;
            transition: all 0.3s ease; /* para suavizar a transição */
            text-align: top;
        }
    </style>
</head>
<body>

<div class="page-wrapper"></div>
<div class="container">
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><path d="M 0,700 C 0,700 0,350 0,350 C 219.5,303 439,256 679,256 C 919,256 1179.5,303 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="#000000" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path></svg>
 



<?php
include "../database/conecta_bd.php"; 

if (isset($_GET['search'])) {
    $searchTerm = $_GET['search']; 

    
    $conexao = obterConexao();

    // Execute a consulta SQL para pesquisar artistas pelo "nick"
    $sql = "SELECT artista.id_artista, cliente.nick FROM artista
            INNER JOIN cliente ON artista.id_cliente = cliente.id_cliente
            WHERE cliente.nick LIKE '%$searchTerm'";

    $result = mysqli_query($conexao, $sql);

    if ($result) {
        
        if (mysqli_num_rows($result) > 0) {
            echo "<h2>Artistas encontrados:</h2>";
            while ($artista = mysqli_fetch_assoc($result)) {
                $artistaId = $artista['id_artista'];
                $artistaNick = $artista['nick'];

                // hiperlinks para as páginas de perfil dos artistas
                echo "<a href='artistas_encontrados.php?id=$artistaId'>$artistaNick</a><br>";

                // Adicione mais informações 
                echo "<br>";
            }
        } else {
            echo "Nenhum artista encontrado com o nick: $searchTerm";
        }
    } else {
        echo "Erro na consulta: " . mysqli_error($conexao);
    }

    
    mysqli_close($conexao);
}
?>
    </div>
</div>
    
    
</body>
</html>

