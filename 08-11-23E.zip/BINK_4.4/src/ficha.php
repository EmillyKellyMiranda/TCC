<?php

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit();
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

$producao = isset($usuario["producao"]) ? $usuario["producao"] : "";
$tempo = isset($usuario["tempo"]) ? $usuario["tempo"] : "";
$valorTotal = isset($usuario["valorTotal"]) ? $usuario["valorTotal"] : "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $producao = isset($_POST["producao"]) ? $_POST["producao"] : "";
    $tempo = isset($_POST["tempo"]) ? $_POST["tempo"] : "";
    $valorTotal = isset($_POST["valorTotal"]) ? $_POST["valorTotal"] : "";

    $conexao = obterConexao();

    if ($conexao) {
            cadastrarFicha($usuario["id_cliente"],  $producao, $tempo, $valorTotal);
            mysqli_close($conexao);
    } else {
        echo "Erro na conexão com o banco de dados!";
    }
}
?>