<?php
    require_once('../PHPMailer/src/PHPMailer.php');
    require_once('../PHPMailer/src/Exception.php');
    require_once('../PHPMailer/src/SMTP.php');

    if (!isset($_SESSION)) {
        session_start();
    }
    require_once("conecta_bd.php");

    function cadastrarCliente($nome, $nick, $data_nascimento, $cpf, $email, $senha){
        $conexao = obterConexao();
        $senha_md5 = md5($senha);
        $sql = "INSERT INTO cliente (nome, nick, data_nascimento, cpf, email, senha) VALUES (?, ?, ?, ?, ?, ?)";
            
        $stmt = $conexao->prepare($sql);/*-> vincula a conexao com o banco com a ação no sql*/ 
        $stmt->bind_param("ssssss", $nome, $nick, $data_nascimento, $cpf, $email, $senha_md5);
        $stmt->execute();
    
        $response = array();
        if ($stmt->affected_rows > 0){
            $response["status"] = "success";
            $response["message"] = "Conta criada com sucesso!";
            $response["location"] = "../public/index.php";
        }else {
            $response["status"] = "error";
            $response["message"] = "Ocorreu um erro com o cadastro, verifique suas credenciais e tente novamente.";
        }
    
        $stmt->close();
        $conexao->close();
    
        return $response;
    }
    

    function buscarUsuario($email, $senha){
        $senha_md5 = md5($senha);
        $sql = "SELECT * FROM cliente
                WHERE email = ? AND senha = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ss", $email, $senha_md5);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        $conexao->close();
        return mysqli_fetch_assoc($resultado);
      }

      function buscarUsuarioPorId($id){
        $sql = "SELECT * FROM cliente WHERE id_cliente = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        $conexao->close();
        return mysqli_fetch_assoc($resultado);
    }

    use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function enviarEmail($email, $token) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'binkifsp@gmail.com';
        $mail->Password = 'mmhfhxiwfevpidee';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('binkifsp@gmail.com', 'B.ink');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Codigo solicitado';
        $mail->Body    = "Seu código BINK é: $token";

        $mail->send();
        echo 'Email enviado com sucesso!';
    } catch (Exception $e) {
        echo "O email não pôde ser enviado. Erro: {$mail->ErrorInfo}";
    }
}
    
    function solicitarRedefinicaoSenha($email){
        $conexao = obterConexao();
        $sql = "SELECT id_cliente FROM cliente WHERE email = ?";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        $conexao->close();
        if ($resultado->num_rows > 0) {
            $token = bin2hex(random_bytes(16)); // Gera um token seguro
            enviarEmail($email, $token);
            return $token;
        } else {
            return false;
        }
    }
    
    function redefinirSenha($email, $senha){
        $conexao = obterConexao();
        $senha_md5 = md5($senha);
        $sql = "UPDATE cliente SET senha = ? WHERE email = ?";
                
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ss", $senha_md5, $email);
        $resultado = $stmt->execute();

        $stmt->close();
        $conexao->close();
        return $resultado;
    }

    
    function alterarEmail($email, $novoEmail) {
        $conexao = obterConexao();
        $sql = "UPDATE cliente SET email = ? WHERE email = ?";
                
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ss", $novoEmail, $email);
        $resultado = $stmt->execute();
    
        $stmt->close();
        $conexao->close();
        return $resultado;
    }
    
    function solicitarAlteracaoEmail($email, $novoEmail){
        $conexao = obterConexao();
        $sql = "SELECT id_cliente FROM cliente WHERE email = ?";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        $conexao->close();
        if ($resultado->num_rows > 0) {
            alterarEmail($email, $novoEmail);
            return true;
        } else {
            return false;
        }
    }
    
?>