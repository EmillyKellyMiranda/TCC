<?php
    session_start();
    include ("../include/cabecalho_logged.php");

    if (!isset($_SESSION["usuario_logado"])) {
        header("Location: ../public/index.php");
    }

    require("../database/funcoes.php");
    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

    $conexao = obterConexao();

    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    $deleta = "DELETE FROM producao WHERE id_producao='$id'";
    $resultado_deleta = mysqli_query($conexao, $deleta);
    //header("location : cadastrar_producao.php");
    echo"<div  style='font-size: 50px; text-align: center; margin-top: 200px;'><p> Etapa apagada com sucesso!!</p> <a href='../src/cadastrar_producao.php'>voltar</a></div>";

    /*if(mysqli_affected_rows($conexao)){
        $_SESSION['msg'] = "<p> Usuário apagado com sucesso!!</p>";
        header("location : cadastrar_producao.php");
    }else{
        $_SESSION['msg'] = "<p> O usuário não pode ser apagado</p>";
        header("location : cadastrar_producao.php");
    }*/



?>