<!DOCTYPE html>
<html>

    <head>
        <title>chat</title>
        <script type="text/javascript">
            function ajax(){

                var req = new XMLHttpRequest();
                req.onreadystatechange = function(){
                    if(req.readyState == 4 && req.status == 200){
                        document.getElementById('chat').innerHTML = req.responseText;
                    }
                }
                req.open('GET', 'chat.php', true);
                req.send();
            }

            setInterval(function(){ajax();}, 1000);
        </script>
    </head>


    <body>
        <div id='chat'>


        </div>

        <form method="post" action="index.php">
            <input type="text" name="nome" placeholder="Nome">
            <input type="text" name="mensagem" placeholder="Mensagem"><br/>
        
            <input type="submit" value="enviar">
        </form>

        <?php
            include("database/bd_conect.php");
            $conexao = Conexao();
            $nome = $_POST['nome'];
            $mensagem = $_POST['mensagem'];
            $conexao->query("INSERT INTO chat1 SET nome='$nome', mensagem='$mensagem'");
        ?>

    </body>
</html>