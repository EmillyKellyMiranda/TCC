<?php

include("../database/funcoes.php");
include("../include/cabecalho_logged.php");


if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    echo($_SESSION["usuario_logado"]);
    
}

echo($_SESSION["usuario_id"]);

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/style_cadastre3.css" rel="stylesheet">
    <script src="js/cadastro_producao.js"></script>

    <style>
        #fundo_form {
            background-color: #000000;
            border-radius: 30px;
        }

        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }

        .btn-custom {
            display: block;
            margin-top: 20px;
            border-radius: 100px;
            width: 50px;
            height: 50px;
            color: #ffffff;
            background-color: #00ffda;
            border-color: #00ffda;
            transition: all 0.3s ease; /* para suavizar a transição */
            text-align: top;
        }
    </style>
</head>
<body>

<?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $tipo_arte = $_POST["tipo_arte"];
        $tempo = $_POST["tempo"];

        $etapas = array(); // Array para armazenar as etapas

        // Percorrer todas as etapas presentes no formulário
        for ($i = 1; $i <= 10; $i++) {
            if (isset($_POST["etapa{$i}"])) {
                $etapas[] = $_POST["etapa{$i}"];
            }
        }
        var_dump($etapas);
        die();
       /* $etapa1 = $_POST["etapa1"];
        $etapa2 = $_POST["etapa2"];
        $etapa3 = $_POST["etapa3"];
        $etapa4 = $_POST["etapa4"];
        $etapa5 = $_POST["etapa5"];
        $etapa6 = $_POST["etapa6"];
        $etapa7 = $_POST["etapa7"];
        $etapa8 = $_POST["etapa8"];
        $etapa9 = $_POST["etapa9"];
        $etapa10 = $_POST["etapa10"];*/

        $conexao = obterConexao();

        /*--------------------------------------------------V-E-R-I-F-I-C-A---P-O-S-T------------------------------------------------------------------------ */

        $sqlVerificacao = "SELECT COUNT(*) FROM producao WHERE arte = ?";
        $stmtVerificacao = mysqli_prepare($conexao, $sqlVerificacao);
        mysqli_stmt_bind_param($stmtVerificacao, "s", $tipo_arte);
        mysqli_stmt_execute($stmtVerificacao);
        mysqli_stmt_bind_result($stmtVerificacao, $contagem);
        mysqli_stmt_fetch($stmtVerificacao);
        mysqli_stmt_close($stmtVerificacao);

        if ($contagem > 0){
            //se o tipo de arte já foi selecionado, a function 'apagarOption($tipo_arte)' deve remover a arte do select em form_cadastrar_producao.php
            require_once("form_cadastrar_producao.php");
            apagarOption($tipo_arte);
        }else {
            $artista_id = $usuario['id_cliente'];
            $num_etapas = count($etapas);

            //$sql = "INSERT INTO producao (id_artista, arte, tempo, etapa1, etapa2, etapa3) VALUES (?, ?, ?, ?, ?, ?)";
            $sql = "INSERT INTO producao (id_artista, arte, tempo";
            // Adicionar as colunas das etapas à consulta
            for ($i = 1; $i <= $num_etapas; $i++) {
                $sql .= ", etapa{$i}";
            }
            $sql .= ") VALUES (?, ?, ?";
            // Adicionar os placeholders das etapas à consulta
            for ($i = 1; $i <= $num_etapas; $i++) {
                $sql .= ", ?";
            }
            $sql .= ")";
            
            $stmt = mysqli_prepare($conexao, $sql);
            //mysqli_stmt_bind_param($stmt, "isssss", $artista_id, $tipo_arte, $tempo, $etapa1, $etapa2, $etapa3);

            $params = array($artista_id, $tipo_arte, $tempo);
            foreach ($etapas as $etapa) {
                $params[] = $etapa;
            }
            // Vincular os parâmetros dinamicamente
            mysqli_stmt_bind_param($stmt, str_repeat("iss", count($params) - 1) . "s", ...$params);

            if (mysqli_stmt_execute($stmt)) {
                echo "Dados cadastrados com sucesso!";
            } else {
                echo "Erro ao cadastrar os dados: " . mysqli_error($conexao);
            }

            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            mysqli_close($conexao);
        }
        /*--------------------------------------------------------------------------------------------------------------------------------------------------- */
    }

?>
<div class="page-wrapper"></div>
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 590" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,200 0,200 C 91.25358851674642,156.1531100478469 182.50717703349284,112.30622009569379 290,128 C 397.49282296650716,143.6937799043062 521.224880382775,218.92822966507174 616,244 C 710.775119617225,269.07177033492826 776.5933014354066,243.98086124401914 855,209 C 933.4066985645934,174.01913875598086 1024.4019138755982,129.14832535885165 1124,126 C 1223.5980861244018,122.85167464114834 1331.7990430622008,161.42583732057417 1440,200 C 1440,200 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.53" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 300)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,400 0,400 C 106.07655502392345,356.3062200956938 212.1531100478469,312.6124401913876 297,337 C 381.8468899521531,361.3875598086124 445.46411483253587,453.8564593301436 539,455 C 632.5358851674641,456.1435406698564 755.9904306220094,365.9617224880383 849,361 C 942.0095693779906,356.0382775119617 1004.5741626794259,436.29665071770336 1098,457 C 1191.4258373205741,477.70334928229664 1315.712918660287,438.8516746411483 1440,400 C 1440,400 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-1" transform="rotate(-180 720 300)"></path></svg>
      <div class="row">
<div id="fundo_form" class="container justify-content-start" style="padding: 50px;">
    <h2>Etapas Cadastradas</h2>
    <ul class="list-group" style="list-style: none;">
        <li class="position-relative top-500 start-90" style="right: 5px; font-size:30px;">
            <a href="form_cadastrar_producao.php"><button class="btn-custom-success btn-lg" type="button">Cadastrar Etapa</button></a>
        </li>
        <li class="lista" style="padding:20px; background-color:#FFFFFF;  ; border-radius: 10px; color: white;">

            <?php
            /*--------------------------------------------------C-O-L-E-T-A---D-A-D-O-S----------------------------------------------------------------------- */
            $conexao = obterConexao();
            $sql = "SELECT * FROM producao WHERE id_artista = ?";
            $stmt = mysqli_prepare($conexao, $sql);
            mysqli_stmt_bind_param($stmt, "i", $usuario['id_cliente']);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            /*------------------------------------------------------------------------------------------------------------------------------------------------ */
           
            /*------------------------------------------------------E-C-H-O---D-A-D-O-S----------------------------------------------------------------------- */

            if (mysqli_num_rows($result) > 0) {
                while ($exibe = mysqli_fetch_assoc($result)) {
                    $sql2 = "SELECT id_producao FROM producao WHERE id_artista = ? AND arte = ?";
                    $stmt2 = mysqli_prepare($conexao, $sql2);
                    mysqli_stmt_bind_param($stmt2, "is", $usuario['id_cliente'], $exibe['arte']);
                    mysqli_stmt_execute($stmt2);
                    mysqli_stmt_store_result($stmt2);
                    mysqli_stmt_bind_result($stmt2, $id_producao);
                    
                    if (mysqli_stmt_fetch($stmt2)) {

                        $_SESSION['id_producao']= $id_producao;
                        echo "<a href='ver_cadastro.php'><p>" . $exibe['arte'] . "</p>";
                        echo "<a href='apaga_cadastro_prod.php?id=".$id_producao." name='excluir'>excluir</a><br/>";
                        

                    } else {
                        echo "Nenhum resultado encontrado.";
                    }
                    
                    mysqli_stmt_close($stmt2);
                }
            }   
            mysqli_stmt_close($stmt);
            mysqli_close($conexao);
            /*------------------------------------------------------------------------------------------------------------------------------------------------ */

            ?>
        </li>
    </ul>
    <button type="button" class="btn btn-custom-danger btn-lg" onclick="window.location.href='perfil.php'">Voltar</button>
</div>
</body>
</html>
