<?php
    include("../include/cabecalho_unlogged.php");
    session_start();
    require_once("../database/funcoes.php");
    
   // Verifica se o formulário foi enviado
if(isset($_POST["codigo"])) {
    $email = $_SESSION["email"];
    $token = $_SESSION["token"];
    $codigo = $_POST["codigo"];
    
    // Verifica se o código de verificação está correto
    if($codigo == obterCodigoVerificacao($email)) {
        // Código correto, atualize o email
        atualizarEmail($email);
        
        // Exiba uma mensagem de sucesso informando que o email foi atualizado
        echo "Seu email foi atualizado com sucesso.";
        
        // Limpa as variáveis de sessão
        unset($_SESSION["email"]);
        unset($_SESSION["token"]);
        
        // Redireciona para a página change_email.php
        header("Location: change_email.php");
        exit;
    } else {
        // Código incorreto, exiba uma mensagem de erro
        echo "O código de verificação está incorreto.";
    }
} else {
    // Enviar o email de verificação
    $email = $_SESSION["email"];
    $token = $_SESSION["token"];
    enviarEmailVerificacao($email, $token);
}

?>
<div class="page-wrapper"></div>
<link rel="stylesheet" type="text/css" href="../css/style_redefinesenha.css" />
<div class="container">
    <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150">
        <defs>
            <linearGradient id="gradient" x1="50%" y1="0%" x2="50%" y2="100%">
                <stop offset="5%" stop-color="#000000"></stop>
                <stop offset="95%" stop-color="#000000"></stop>
            </linearGradient>
        </defs>
        <path d="M 0,700 C 0,700 0,350 0,350 C 148.2666666666667,411.3333333333333 296.5333333333334,472.66666666666663 479,439 C 661.4666666666666,405.33333333333337 878.1333333333332,276.6666666666667 1044,246 C 1209.8666666666668,215.33333333333331 1324.9333333333334,282.66666666666663 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1.0" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path>
    </svg>
    <div class="row">
        <div class="col-md-6 mb-5">
            <h3>Confirme o <span>código</span> recebido para atualizar o seu <span>email</span>.</h3>
            <form action="atualizar_email.php" method="post">
                <div class="form-group">
                    <label for="codigo">Código:</label>
                    <input type="text" class="form-control" id="codigo" name="codigo" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Confirmar</button>
                </div>
            </form>
        </div>
        <div class="col-md-6">
            <div class="forgot-password-image">
                <img src="../images/esqueci_senha.png" alt="Imagem Esqueci Minha Senha">
            </div>
        </div>
    </div>
</div>

<?php include("../include/rodape.php"); ?>
