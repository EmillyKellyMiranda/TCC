DROP DATABASE IF EXISTS bink;
CREATE DATABASE bink;
USE bink;

CREATE TABLE cliente (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(20) NOT NULL, 
    nick VARCHAR(20) NOT NULL,
    data_nascimento VARCHAR(20) NOT NULL, 
    cpf VARCHAR(11) NOT NULL, 
    email VARCHAR(255) NOT NULL, 
    senha VARCHAR(50) NOT NULL,
    foto_perfil VARCHAR(255) DEFAULT NULL,
    is_artist BOOLEAN DEFAULT 0
);

INSERT INTO cliente (nome, nick, data_nascimento, cpf, email, senha) VALUES
('admin', 'adm', '21/01/2005', '49190448871', 'admin@admin.com', 'admin'),
('user', 'user0', '2005-01-01', '00000000000', 'user@gmail.com', '5725dbcc7254ee8422d1cb60db29625c');


CREATE TABLE tipo_arte (
    id_tipo_arte INT PRIMARY KEY AUTO_INCREMENT, 
    arte VARCHAR(255) NOT NULL
);

INSERT INTO tipo_arte (arte) VALUES
('Animação'),
('Desenho digital'),
('Desenho físico'),
('Escultura'),
('Pintura');




/* Artista também é um cliente */
CREATE TABLE artista (
    id_artista INT NOT NULL AUTO_INCREMENT,
    id_cliente INT NOT NULL,
    id_tipo_arte INT NOT NULL,
    PRIMARY KEY (id_artista),
    FOREIGN KEY (id_cliente) REFERENCES cliente (id_cliente) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_tipo_arte) REFERENCES tipo_arte (id_tipo_arte) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE curriculo (
    id_artista INT NOT NULL AUTO_INCREMENT,
    localizacao VARCHAR(200),
    localizacao2 VARCHAR(200),
    sobre_artista VARCHAR(200),
    formacao VARCHAR(200),
    estilo_arte VARCHAR(200),
    contato VARCHAR(200),
    FOREIGN KEY (id_artista) REFERENCES cliente(id_cliente) ON DELETE CASCADE ON UPDATE CASCADE
);



CREATE TABLE producao (
    id_producao INT PRIMARY KEY AUTO_INCREMENT,
    id_artista INT NOT NULL,
    arte VARCHAR(255),
    tempo INT,
    etapa1 VARCHAR(200),
    etapa2 VARCHAR(200),
    etapa3 VARCHAR(200),
    etapa4 VARCHAR(200),
    etapa5 VARCHAR(200),
    etapa6 VARCHAR(200),
    etapa7 VARCHAR(200),
    etapa8 VARCHAR(200),
    etapa9 VARCHAR(200),
    etapa10 VARCHAR(200),
    FOREIGN KEY (id_artista) REFERENCES cliente (id_cliente) ON DELETE CASCADE ON UPDATE CASCADE
   
);

/*CREATE TABLE adiciona_etapa(
    id_etapa INT PRIMARY KEY AUTO_INCREMENT,
    etapaN VARCHAR(200),
    producao INT,
    FOREIGN KEY (producao) REFERENCES producao(id_producao)
);

  -ainda vai ser adicionada.

CREATE TABLE postagens (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    arquivo VARCHAR(255) NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    legenda VARCHAR(255) DEFAULT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;*/

CREATE TABLE ficha(
    id_producao_ficha PRIMARY KEY AUTO_INCREMENT,
    producao VARCHAR(255) NOT NULL, 
    FOREIGN KEY (id_producao) REFERENCES arte (id_producao),
    nome_cliente VARCHAR(255) NOT NULL,

)
