<?php
    session_start();
    include ("../include/cabecalho_logged.php");
    
    if (!isset($_SESSION["usuario_logado"])) {
        header("Location: ../public/index.php");
        echo($_SESSION["usuario_logado"]);
        
    }

?>
    
<!DOCTYPE html>
<html lang="pt">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="../css/style_cadastre4.css" rel="stylesheet">
        <script src="js/cadastro_producao.js"></script>

        <style>
           

            .btn-custom2 {
                display: flex;
                margin-top: 70px;
                margin-left: 780px;
                border-radius: 10px;
                padding-top: 2px;
                width: 190px;
                border:200px;
                color: black;
                text-align: center;
                
            }
        </style>
    </head>
    <body>
        
    <?php
        if (!isset($_SESSION["usuario_logado"])) {
            header("Location: ../public/index.php");
        }

        require("../database/funcoes.php");
        $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

        $conexao = obterConexao();

        $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
        $deleta = "DELETE FROM producao WHERE id_producao='$id'";
        $resultado_deleta = mysqli_query($conexao, $deleta);
        //header("location : cadastrar_producao.php");
        echo"<div  style='font-size: 50px; text-align: center; margin-top: 200px;'><p > Produção apagada com sucesso!!
        </p></div> <div > <a href='../src/cadastrar_producao.php'  ><h3 style='color: #00ffdas; font-weight: bold; text_align:center;'>voltar</h3></a></div>";

        /*if(mysqli_affected_rows($conexao)){
            $_SESSION['msg'] = "<p> Usuário apagado com sucesso!!</p>";
            header("location : cadastrar_producao.php");
        }else{
            $_SESSION['msg'] = "<p> O usuário não pode ser apagado</p>";
            header("location : cadastrar_producao.php");
        }*/



    ?>
    </body>
<head>
