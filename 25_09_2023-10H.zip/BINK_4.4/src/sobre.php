<?php
    include ("../include/cabecalho_unlogged.php");
?>

<!DOCTYPE html>
<html lang="pt">
<body>
<div class="container">
  <div class="row">
    <div class="col-sm">
      Uma de três colunas
    </div>
    <div class="col-sm">
      Uma de três colunas
    </div>
    <div class="col-sm">
      Uma de três colunas
    </div>
  </div>
</div>
</body>
</html>