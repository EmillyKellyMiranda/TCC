<?php
ob_start();
session_start();

include("../database/funcoes.php");
include ("../include/cabecalho_logged.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/style_cadastre4.css" rel="stylesheet">
    <script src="js/form_cadastrar_producao.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        #fundo_form {
            background-color: #000000;
            border-radius: 30px;
            padding: 100px;
        }

        .h4{
            margin-top: 100px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: center;
        }
        .container{
            padding:50px !important;
        }
        .btn-custom-success {
            display: block;
            margin-top: 20px;
            border-radius: 20px;
            width: 300px;
            height: 40px;
            color: #ffffff;
            background-color: #00ffda;
            border-color: #00ffda;
            transition: all 0.3s ease; /* para suavizar a transição */
        }

        .btn-custom-success:hover {
            color: #0a0a0a;
            background-color: #01a78e;
            border-color: #01a78e;
        }
        .mini-card {
    background-color: #000;
    border-radius: 10px;
    color: #fff;
    padding: 10px;
    margin: 10px;
    width: calc(33.3% - 20px); /* Calcula a largura para caber três cards com margens de 10px entre eles */
    float: left; /* Alinha os cards horizontalmente */
    box-sizing: border-box; /* Garante que a largura inclua padding e bordas */
}

/* Limpa as margens das linhas para que os cards possam ficar próximos */
.card-container::after {
    content: "";
    display: table;
    clear: both;
}

.card-title {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 8px;
}

.card-text {
    font-size: 14px;
    margin-bottom: 5px;
}



    </style>

</head>
<body>


<?php


    if (isset($_SESSION["usuario_logado"])){ ?>
        <div class="text-center" style="margin-top: 150px">
            <h3 class="mt-5 text-black">Você está logado como <?= $_SESSION["usuario_logado"] ?></h3>
        <?php } ?>
    </div> 

<?php
    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
$conexao1 = obterConexao();
$sql1 = "SELECT id_artista FROM artista WHERE id_cliente = ?";
$stmt1 = mysqli_prepare($conexao1, $sql1);
mysqli_stmt_bind_param($stmt1, "i", $usuario["id_cliente"]);
mysqli_stmt_execute($stmt1);
$resultado = mysqli_stmt_get_result($stmt1);

while ($row = mysqli_fetch_assoc($resultado)) {
    $id_artista = $row['id_artista'];
    // Faça o que quiser com $id_cliente
}
mysqli_close($conexao1);

$conexao = obterConexao();

if (!$conexao) {
    echo "Erro na conexão com o banco de dados!";
    exit();
}

$fichas = obterDadosFicha($id_artista);

foreach ($fichas as $ficha) { ?>
    <div class="mini-card">
        <div class="card-body">
        <h5 class="card-title" style="color: #fff;">Nome da Produção: <?= $ficha["nome_producao"] ?></h5>
        <p class="card-text" style="color: #fff;">Tipo de arte: <?= $ficha["tipo_arte"] ?></p>
        <p class="card-text" style="color: #fff;">Tempo: <?= $ficha["tempo"] ?> dias</p>
        <p class="card-text" style="color: #fff;">Valor Total: <?= $ficha["valorTotal"] ?></p>
        <?php
        $etapas = $ficha["etapas"];
        foreach ($etapas as $numero => $descricao) {
            echo "<p class='card-text' style='color: #fff;'>Etapa de Produção $numero: $descricao</p>";
        }
        ?>
            <form method="POST">
                <input type="hidden" name="ficha_id" value="<?= $ficha['id_ficha'] ?>">
                <button type="submit" class="btn btn-danger">Excluir Ficha</button>
            </form>
        </div>
    </div>
<?php }

function obterDadosFicha($id_artista) {
    $conexao = obterConexao();

    $sql = "SELECT nome_producao, arte, tempo, valorTotal FROM ficha WHERE id_artista = ?";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_artista);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $nome_producao, $arte, $tempo, $valorTotal);

    $fichas = [];
    while (mysqli_stmt_fetch($stmt)) {
        $fichas[] = [
            "nome_producao" => $nome_producao,
            "tipo_arte" => $arte,
            "etapas" => obterEtapas($id_artista, $arte),
            "tempo" => $tempo,
            "valorTotal" => $valorTotal
        ];
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conexao);

    return $fichas;
}

function obterEtapas($id_artista, $arte) {
  $conexao = obterConexao();
  $sql = "SELECT etapa1, etapa2, etapa3, etapa4, etapa5, etapa6, etapa7, etapa8, etapa9, etapa10 FROM ficha WHERE id_artista = ? AND arte = ?";
  $stmt = mysqli_prepare($conexao, $sql);
  mysqli_stmt_bind_param($stmt, "is", $id_artista, $arte);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);

  $etapas = [];

  if ($result->num_rows > 0) {
      $row = mysqli_fetch_assoc($result);
      foreach ($row as $key => $value) {
          if (!empty($value)) {
              $etapas[$key] = $value;
          }
      }
  }

  mysqli_stmt_close($stmt);
  mysqli_close($conexao);

  return $etapas;
}
?>

<div class="page-wrapper"></div>
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 590" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,200 0,200 C 91.25358851674642,156.1531100478469 182.50717703349284,112.30622009569379 290,128 C 397.49282296650716,143.6937799043062 521.224880382775,218.92822966507174 616,244 C 710.775119617225,269.07177033492826 776.5933014354066,243.98086124401914 855,209 C 933.4066985645934,174.01913875598086 1024.4019138755982,129.14832535885165 1124,126 C 1223.5980861244018,122.85167464114834 1331.7990430622008,161.42583732057417 1440,200 C 1440,200 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.53" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 300)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,400 0,400 C 106.07655502392345,356.3062200956938 212.1531100478469,312.6124401913876 297,337 C 381.8468899521531,361.3875598086124 445.46411483253587,453.8564593301436 539,455 C 632.5358851674641,456.1435406698564 755.9904306220094,365.9617224880383 849,361 C 942.0095693779906,356.0382775119617 1004.5741626794259,436.29665071770336 1098,457 C 1191.4258373205741,477.70334928229664 1315.712918660287,438.8516746411483 1440,400 C 1440,400 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-1" transform="rotate(-180 720 300)"></path></svg>


</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="js/agrupaEtapa.js"></script>
</body>
</html>