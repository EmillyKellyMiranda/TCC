<?php
include("../database/funcoes.php");

$var = $_GET['Parametro_arte'];
$id_artista = $_GET['id_artista'];

if ($var !== null) {
    $conexao3 = obterConexao();
    $htmlEtapas = '';

    for ($i = 1; $i < 11; $i++) {
        $sql3 = "SELECT etapa$i FROM producao WHERE id_artista = ? AND arte = ?";
        $stmt3 = mysqli_prepare($conexao3, $sql3);
        mysqli_stmt_bind_param($stmt3, "is", $id_artista, $var);
        mysqli_stmt_execute($stmt3);
        $etapa = mysqli_stmt_get_result($stmt3);

        // Verifica se há resultados
        if ($etapa !== null) {
            // Itera sobre os resultados
            while ($linha = mysqli_fetch_assoc($etapa)) {
                $etapaAtual = $linha["etapa$i"];
                if ($etapaAtual !== null) {
                    $htmlEtapas .= " 
                        <div class='mb-3'>
                            <label for='etapa[$i]' class='form-label'>Etapa de Produção $i:</label>
                            <input type='text' class='form-control' id='etapa[$i]' name='etapa[$i]' placeholder='$etapaAtual' disabled>
                        </div>";
                }
            }
        } else {
            $htmlEtapas = "<p>Nenhum resultado encontrado.</p>";
        }
        mysqli_stmt_close($stmt3);
    }

    mysqli_close($conexao3);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $conexao = obterConexao();
        if ($conexao) {
            for ($i = 1; $i < 11; $i++) {
                $etapaProducao = $_POST['etapa'][$i] ?? null;
                if ($etapaProducao !== null) {
                    salvarEtapasNoBanco($id_artista, $var, $i, $etapaProducao, $conexao);
                }
            }
            mysqli_close($conexao);
        }
    }

    echo $htmlEtapas;
} else {
    echo "<p style='color:pink;'>Escolha um tipo de arte!!!</p>";
}

function salvarEtapasNoBanco($id_artista, $var, $numero_etapa, $etapa, $conexao) {
    $sql = "UPDATE producao SET etapa$numero_etapa = ? WHERE id_artista = ? AND arte = ?";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "sis", $etapa, $id_artista, $var);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}
?>
