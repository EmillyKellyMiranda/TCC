<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["imagem"])) {
    $targetDir = "fotos/"; // Especifique o caminho para salvar as imagens
    $targetFile = $targetDir . basename($_FILES["imagem"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Verificar se o arquivo é uma imagem real
    $check = getimagesize($_FILES["imagem"]["tmp_name"]);
    if ($check === false) {
        echo "O arquivo enviado não é uma imagem.";
        $uploadOk = 0;
    }

    // Verificar se o arquivo já existe
    if (file_exists($targetFile)) {
        echo "Um arquivo com o mesmo nome já existe.";
        $uploadOk = 0;
    }

    // Verificar o tamanho máximo do arquivo (opcional)
    if ($_FILES["imagem"]["size"] > 500000) {
        echo "O tamanho do arquivo é muito grande. Por favor, escolha uma imagem menor.";
        $uploadOk = 0;
    }

    // Permitir apenas determinados formatos de arquivo (opcional)
    if ($imageFileType !== "jpg" && $imageFileType !== "jpeg" && $imageFileType !== "png" && $imageFileType !== "gif") {
        echo "Apenas arquivos JPG, JPEG, PNG e GIF são permitidos.";
        $uploadOk = 0;
    }

    // Verificar se houve algum erro durante o upload
    if ($uploadOk === 0) {
        echo "O arquivo não pôde ser enviado.";
    } else {
        // Salvar a imagem no servidor
        if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $targetFile)) {
            echo "A imagem foi enviada com sucesso.";

            // Exibir a imagem na seção de portfólio
            echo '<div class="portfolio-image">';
            echo '<img src="' . $targetFile . '" alt="Imagem do Portfólio">';
            echo '</div>';
        } else {
            echo "Ocorreu um erro ao enviar o arquivo.";
        }
    }
}
?>