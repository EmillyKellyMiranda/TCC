<?php 
    session_start();
    include ("../include/cabecalho_logged.php");

    if (!isset($_SESSION["usuario_logado"])){
        header("Location: ../public/index.php");
    }

    require("../database/funcoes.php");
    $usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);
   
     $conexao = obterConexao();
   
    /*-------------------------------------C-R-I-A------ID-_-M-E-N-S-A-G-E-N-S---------------------------------------------------------------------------- */
    // -> A variavel $id_mensagens é resposável pelo campo "id_mens" no banco de dados
    //e será por ela que faremos a requisição de todas as conversas entre usuario 1 e 2
    $user = $_SESSION["id_user"];
    $meu_id = $usuario['id_cliente'];

    if($meu_id>$user){
        $id_mensagens = $user.$meu_id;
    }else{
        $id_mensagens = $meu_id.$user;
    }
    /*------------------------------------------------------------------------------------------------------------------------------------ */

?>




<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Página de Perfil</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../css/style_cabecalho_unlogged.css" />
        <script src="js/chat.js"></script>


        <style>
            .center-both {
                display: flex;
                justify-content: center;
                height: 60vh;
                width:80vh;
                background:#e4ebe5;
                margin-top: 25vh;
            }
            .card-body{
                margin-top: none;
            }
        </style>  
    </head>




    <body>
        <div class="container-sm center-both">
            <div class="card-body text-rigth" >

        <!--------------------------------------------------M-O-S-T-R-A---C-H-A-T--------------------------------------------------------------------->
            <div id='chat'>
                    <?php  
                             
                        require_once("../database/conecta_bd.php");
                        $conexao = obterConexao();

                        $sql_recebe= "SELECT mensagem FROM chat WHERE id_mens=?";
                        $stmt_recebe = mysqli_prepare($conexao, $sql_recebe);
                        mysqli_stmt_bind_param($stmt_recebe, "i", $id_mensagens);
                        mysqli_stmt_execute($stmt_recebe);
                        mysqli_stmt_bind_result($stmt_recebe, $recebe_mens);
                
                        while (mysqli_stmt_fetch($stmt_recebe)) {
                            echo "<p >".$recebe_mens."</p></br>";
                        }
                        
                        mysqli_stmt_close($stmt_recebe);
                    ?>
            </div>
        <!--------------------------------------------------------------------------------------------------------------------------------------->

        <!--------------------------------------------------A-J-A-X----------------------------------------------------------------------------->
        <script type="text/javascript">
             
             function ajax(){
                var req = new XMLHttpRequest();
                req.onreadystatechange = function(){
                    if(req.readyState == 4 && req.status == 200){
                        document.getElementById('chat').innerHTML = req.responseText;
                    }
                }
                req.open('GET', 'chat2.php', true);
                req.send();
            }

            setInterval(function(){ajax();}, 1000);
        </script>
        <!---------------------------------------------------------------------------------------------------------------------------------->

                <div class="container" id="campo_de_texto" >
                    <form method="post" action="chat2.php" id="formulario" name="formulario">
                        <input type="text" id="mensagem" name="mensagem" placeholder="Mensagem"><br/>
                        <input type="submit" value="enviar" id="enviar" name="enviar">
                    </form>
                </div>
            </div>    
        </div>
                
        
        <?php
                if (isset($_POST['mensagem']) && !empty($_POST['mensagem'])) {
                    $mensagem = $_POST['mensagem'];
                } else {
                    // Lida com o caso em que 'mensagem' não foi enviado no POST/'mensagem' é um campo vazio
                    $mensagem = "";
                }
                         
                
                /*---------------------------------------C-O-L-E-T-A----D-A-D-O-S---------------------------------------------------------- */
                    $sql = "SELECT id_mens FROM chat WHERE id_1 = ? AND id_2 = ?";
                    $stmt = mysqli_prepare($conexao, $sql);
                    mysqli_stmt_bind_param($stmt, "ii", $meu_id, $user);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_bind_result($stmt, $ver1);

                    $conexao2 = obterConexao();

                    $sql2 = "SELECT id_mens FROM chat WHERE id_1 = ? AND id_2 = ?";
                    $stmt2 = mysqli_prepare($conexao2, $sql2);
                    mysqli_stmt_bind_param($stmt2, "ii", $user, $meu_id);
                    mysqli_stmt_execute($stmt2);
                    mysqli_stmt_bind_result($stmt2, $ver2);

                    if (mysqli_stmt_fetch($stmt)||mysqli_stmt_fetch($stmt2)) {
                        //se $stmt ou $stmt2 existirem = insere valores no mensagem da tababela chat, onde primary key = $stmt
                            
                        mysqli_stmt_close($stmt);
                        mysqli_stmt_close($stmt2);

                        if($mensagem!==""){
                            $sql_mensagem= "INSERT INTO chat (id_mens, id_1, id_2, mensagem) VALUES (?, ?, ?, ?)";
                            $stmt_mensagem = mysqli_prepare($conexao, $sql_mensagem);
                            mysqli_stmt_bind_param ($stmt_mensagem, "iiis", $id_mensagens, $meu_id, $user, $mensagem);
                            mysqli_stmt_execute($stmt_mensagem);

                            mysqli_stmt_close($stmt_mensagem);
                        }
                    } else {
                            
                        if($mensagem!==""){
                                
                            $sql_mensagem2= "INSERT INTO chat (id_mens, id_1, id_2, mensagem) VALUES (?, ?, ?, ?)";
                            $stmt_mensagem2 = mysqli_prepare($conexao, $sql_mensagem2);
                            mysqli_stmt_bind_param ($stmt_mensagem2, "iiis", $id_mensagens, $meu_id, $user, $mensagem );
                            mysqli_stmt_execute($stmt_mensagem2);
                            mysqli_stmt_close($stmt_mensagem2);
                            
                        }
                    }
                /*------------------------------------------------------------------------------------------------------------------------- */

            ?>





        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>