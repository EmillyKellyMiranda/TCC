<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.ink/Ficha - formulário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">    
    <style>
        .chat-container {
            display: flex;
            align-items: flex-start;
        }
        #section {
            border-color: white;
            border-style: inset;
            border-width: 9px;
            background-color: white;
            margin-bottom: 50px;
            margin-left: 50px;
            margin-right: 800px;
            margin-top: 50px;
            text-align: center;
        }
    
        .form-container {
            display: none;
            border-color: white;
            border-style: none;
            border-width: 9px;
            background-color: white;
            margin-left: 830px;
            margin-right: 50px;
            position: relative;
            top: -650px;
            left: 20px;
            width: 650px;
        }
    </style>
</head>


<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>


    <section id='section'>
        <div class="chat-container">
            <div class="chat-box">
            <!-- Chat -->
                <h2>Chat</h2>
                <img src="chat.jpg" width="300" height="500"></img><br>
                <button class="btn btn-success" id="showFormButton">Negociação</button>
            </div>
    </section>
            <div class="form-container" id="formContainer">

            <!-- Form -->
            <form action="arquivo.php" method="post"> <!-- para editar -->
                
                <div class="mb-3">
                    <label for="fichaproducao" class="form-label">Produção:</label>
                    <input type="text" class="form-control" id="fichaproducao" placeholder="Exemplo: Quadro da família Alves">
                </div>
                <div class="mb-3">
            <label for="tipoObra" class="form-label">Tipo da Obra:</label>
            <select class="form-control" id="tipoObra" name="tipoObra" onchange="showEtapas()">
                <option value="selecione">Selecione</option>
                <option value="obra1">Obra 1</option>
                <option value="obra2">Obra 2</option>
                <option value="obra3">Obra 3</option>
            </select>
        </div>

        <div id="etapasProducao" style="display:none;">
            <div class="mb-3">
                <label for="etapa1" class="form-label">Etapa de Produção 1:</label>
                <input type="text" class="form-control" id="etapa1" name="etapa1" disabled>
            </div>
            <div class="mb-3">
                <label for="etapa2" class="form-label">Etapa de Produção 2:</label>
                <input type="text" class="form-control" id="etapa2" name="etapa2" disabled>
            </div>
            <div class="mb-3">
                <label for="etapa3" class="form-label">Etapa de Produção 3:</label>
                <input type="text" class="form-control" id="etapa3" name="etapa3" disabled>
            </div>
        </div>
        
                <div class="mb-3">
                    <label for="fichacliente" class="form-label">Cliente:</label>
                    <input type="text" class="form-control" id="fichacliente" placeholder="Nome do cliente">
                </div>
                <div class="mb-3" style="display: flex; gap: 10px;">
                    <label for="pais" class="form-label">País:</label>
                    <input type="text" class="form-control" id="pais" name="pais" required>

                    <label for="estado" class="form-label">Estado:</label>
                    <input type="text" class="form-control" id="estado" name="estado" required>

                    <label for="cidade" class="form-label">Cidade:</label>
                    <input type="text" class="form-control" id="cidade" name="cidade" required>
                </div>
                <p>/ vai ser adicionado a api depois /<p>
                <div class="mb-3">
                    <label for="valorTotal" class="form-label">Valor total:</label>
                    <input type="text" class="form-control" id="valorTotal" name="valorTotal" oninput="formatCurrency(this)" pattern="^\d+(\.\d{2})?$" placeholder="R$" required>
                </div>
            
                <button type="submit" class="btn btn-primary">Registrar</button>
            </form>
            </div>
        </div>
    


    <script>
        /* pra fazer aparecer a ficha do lado */
        const showFormButton = document.getElementById("showFormButton");
        const formContainer = document.getElementById("formContainer");

        showFormButton.addEventListener("click", () => {
            formContainer.style.display = "block";
        });


        /** formulário */
        function formatCurrency(input) {
            const value = input.value.replace(/\D/g, ""); // Remove todos os caracteres não numéricos
            const formattedValue = (value / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            input.value = formattedValue;
        }

        function showEtapas() {
            const tipoObra = document.getElementById("tipoObra").value;
            const etapasDiv = document.getElementById("etapasProducao");

            if (tipoObra === "selecione") {
                etapasDiv.style.display = "none";
            } else {
                etapasDiv.style.display = "block";
                document.getElementById("etapa1").disabled = true;
                document.getElementById("etapa2").disabled = true;
                document.getElementById("etapa3").disabled = true;
            }
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>