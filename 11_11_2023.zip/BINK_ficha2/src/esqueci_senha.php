<?php
    include("../include/cabecalho_unlogged.php");
    session_start();
    require_once("../database/funcoes.php");
    
    if(isset($_POST["email"])) {
        $email = $_POST["email"];
        $token = rand(100000, 999999);
        enviarEmail($email, $token);
        
        // Armazene o email e o token em variáveis de sessão
        $_SESSION["email"] = $email;
        $_SESSION["token"] = $token;
        
        // Redirecione o usuário para a página de confirmação do código
        header("Location: confirma_codigo.php");
    }
?>
<div class="page-wrapper"></div>
<link rel="stylesheet" type="text/css" href="../css/style_redefinesenha.css" />
<div class="container">
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="50%" y1="0%" x2="50%" y2="100%"><stop offset="5%" stop-color="#000000"></stop><stop offset="95%" stop-color="#000000"></stop></linearGradient></defs><path d="M 0,700 C 0,700 0,350 0,350 C 148.2666666666667,411.3333333333333 296.5333333333334,472.66666666666663 479,439 C 661.4666666666666,405.33333333333337 878.1333333333332,276.6666666666667 1044,246 C 1209.8666666666668,215.33333333333331 1324.9333333333334,282.66666666666663 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1.0" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path></svg>
<div class="row">
    <div class="col-md-6 mb-5">
    <h3>Enviaremos um <span>código</span> para que você possa redefinir a sua <span>senha</span>.<h3>
    <form action="esqueci_senha.php" method="post">
        <label for="email">Digite seu email:</label><br>
        <input type="email" id="email" name="email" required><br>
        <input class="btn btn-custom-success" type="submit" value="Enviar código">
        <button type="button" class="btn btn-custom-danger ml-0" onclick="window.history.back()">Voltar</button>

    </form> 
    </div>
    <div class="col-md-6">
      <div class="imagem mb-6">
        <img src="../img/arte.png" alt="Imagem" class="img-fluid">
      </div>
    </div>
</div>
    
</div>
