<?php
session_start();

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
}

require ("../database/funcoes.php");


if ($_FILES["foto_perfil"]["error"] == UPLOAD_ERR_OK) {
    $pasta_upload = "fotos/";
    $extensao_arquivo = strtolower(pathinfo($_FILES["foto_perfil"]["name"], PATHINFO_EXTENSION));
    $nome_arquivo = uniqid() . '.' . $extensao_arquivo;
    $caminho_arquivo = $pasta_upload . basename($nome_arquivo);
    $uploadOk = 1;



    // Verifique o tamanho do arquivo
    if ($_FILES["foto_perfil"]["size"] > 500000) {
        echo "O arquivo é muito grande.";
        $uploadOk = 0;
    }

    // Permitir apenas determinados formatos de arquivo
    $extensao_arquivo = strtolower(pathinfo($caminho_arquivo, PATHINFO_EXTENSION));
    if ($extensao_arquivo != "jpg" && $extensao_arquivo != "png" && $extensao_arquivo != "jpeg" && $extensao_arquivo != "gif") {
        echo "Apenas arquivos JPG, JPEG, PNG e GIF são permitidos.";
        $uploadOk = 0;
    }
    
    
    // Verifique se $uploadOk está definido como 0 por um erro
    if ($uploadOk == 0) {
        echo "Desculpe, seu arquivo não foi enviado.";
    // Se tudo estiver ok, tente fazer o upload do arquivo
    } else {
        if (move_uploaded_file($_FILES["foto_perfil"]["tmp_name"], $caminho_arquivo)) {
            echo "O arquivo ". basename($nome_arquivo). " foi enviado.";
            atualizarFotoPerfil($_SESSION["usuario_id"], $caminho_arquivo);
            header("Location: perfil.php");
        } else {
            echo "Desculpe, houve um erro ao enviar seu arquivo.";
        }
    }
} else {
    echo "Nenhum arquivo enviado.";
}

function atualizarFotoPerfil($id_cliente, $foto_perfil) {
    $conexao = obterConexao();
    $sql = "UPDATE cliente SET foto_perfil = ? WHERE id_cliente = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("si", $foto_perfil, $id_cliente);
    $stmt->execute();

    if ($stmt->affected_rows > 0){
        echo "Foto de perfil atualizada com sucesso!";
    }else {
        echo "Ocorreu um erro ao atualizar a foto de perfil.";
    }

    $stmt->close();
    $conexao->close();
}


?>
