<?php
    require ("../database/funcoes.php");
    require ("../include/cabecalho_unlogged.php");
?>
<div class='sucesso-criar'>Senha alterada com sucesso!<br>
<a class='sucesso-botao' href='../public/index.php'>Entrar</a>
</div>