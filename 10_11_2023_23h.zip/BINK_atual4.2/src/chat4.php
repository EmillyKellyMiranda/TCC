             
                            <?php
                                function addContato(){
                                    $conexao3 = obterConexao();

                                    $sql3 = "SELECT id_cliente, id_addContato FROM contatos WHERE id_cliente = {$usuario['id_cliente']} AND id_addContato = {$user_selecionado['id_cliente']}";
                                    $stmt3 = mysqli_prepare($conexao3, $sql3);
                                    mysqli_stmt_bind_param($stmt3, "i", $user_selecionado["id_cliente"]);
                                    mysqli_stmt_execute($stmt3);
                                    $resultado = mysqli_stmt_get_result($stmt3);
                                    $num_linhas = mysqli_num_rows($resultado);

                                    if($num_linhas>0){
                                        //depois precisa tratar essa possibilidade adequadamente
                                        //mudando o texto do botão para "excluir usuário" e 
                                        //fazendo com que se cair nesse if ele exclua o user dos contatos.
                                        echo"ESSE USUÁRIO JÁ FOI ADICIONADO AOS CONTATOS";
                                        mysqli_stmt_close($stmt3);
                                        mysqli_close($conexao3);


                                    }else{
                                        $sql4 = "INSERT INTO contatos (id_cliente, id_addContato, nome_addContato) VALUES (?, ?, ?)";
                                        $stmt4 = mysqli_prepare($conexao3, $sql4);
                                        mysqli_stmt_bind_param($stmt4, "iis", $usuario["id_cliente"], $user_selecionado["id_cliente"], $user_selecionado["nick"]);
                                        mysqli_stmt_execute($stmt4);
                                        mysqli_stmt_close($stmt4);
                                        mysqli_close($conexao3);

                                    }
                                    

                                }
                            ?>

"use strict";
window.onload = function() {

    var addContato = document.getElementById("btn_add_contato");

    addContato.onclick = function(){
        if(addContato.value === "0"){
            var texto = 'Adicionado';
            addContato.innerHTML = texto;
            addContato.value = "1";
            retornaStatus(addContato.value);


        }else{
            var texto = 'Adicionar contato';
            addContato.innerHTML = texto;
            addContato.value = "0";
            retornaStatus(addContato.value);
        }


    }

    function retornaStatus(valor){
        var status_add= valor;
        console.log(status_add);
        return status_add;
    }


}
