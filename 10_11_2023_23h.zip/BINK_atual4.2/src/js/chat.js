"use strict";
window.onload = function() {
    /*-------------------------------------P-E-G-A---ID-_-USER--------------------------------------------------------------------*/ 
    $('.user-link').click(function(event) {
        event.preventDefault();

        var id_user = $(this).attr('id');

        $.ajax({
            type: 'POST',
            url: 'atualizar_sessao.php',
            data: { id_user: id_user },
            success: function(response) {
                console.log(response);
                window.location.href = 'chat2.php';
            },
            error: function() {
                console.error('Erro na solicitação AJAX');
            }
        });
    });
    /*----------------------------------------------------------------------------------------------------------------------------*/ 
}
