"use strict";
window.onload = function() {
    function cadastroID(){
        var id_prod = document.getElementById($id_producao);
        id_prod.onclick = retornaID;
    }


    function retornaID(){
        return id_prod;
    }
}
