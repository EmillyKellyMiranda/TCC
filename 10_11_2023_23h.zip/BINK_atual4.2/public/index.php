<?php
require("../database/funcoes.php");
require("../include/cabecalho_unlogged.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>B.ink</title>
  <link rel="stylesheet" type="text/css" href="../css/style_index.css" />
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
</head>
<body>
  <div class="page-wrapper"></div>
  <div class="container">
    <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150">
      <defs>
        <linearGradient id="gradient" x1="50%" y1="0%" x2="50%" y2="100%">
          <stop offset="5%" stop-color="#000000"></stop>
          <stop offset="95%" stop-color="#000000"></stop>
        </linearGradient>
      </defs>
      <path d="M 0,700 C 0,700 0,350 0,350 C 148.2666666666667,411.3333333333333 296.5333333333334,472.66666666666663 479,439 C 661.4666666666666,405.33333333333337 878.1333333333332,276.6666666666667 1044,246 C 1209.8666666666668,215.33333333333331 1324.9333333333334,282.66666666666663 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1.0" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path>
    </svg>
    <div class="row">
      <div class="col-md-6">
        <h3>Com a B.ink, você pode adquirir <span>artes</span> autênticas com <span>facilidade</span> e <span>confiança</span></h3>
        <form action="../src/recupera_login.php" method="POST" class="formulario">
          <div class="form-group mt-5">
            <label for="id_email" class="email">Email: </label>
            <input class="form-control input-pequeno" type="email" name="email" id="id_email" required />
          </div>
          <div class="form-group">
            <label for="senha" class="senha">Senha:</label>
            <div class="input-group">
              <input class="form-control input-grande" type="password" name="senha" id="id_senha" required/>
              <div class="input-group-append">
                <span class="input-group-text"><i id="icon-eye" class="fas fa-eye-slash"></i></span>
              </div>
            </div>
          </div>
          <a href="../src/esqueci_senha.php">Esqueceu sua senha?</a>
          <div class="row">
            <div class="col-8"></div>
          </div>
          <button type="submit" class="btn btn-custom-success" name="login" value="login">Entrar</button>
          <div class="col-4 text-center mt-3">
            <div class="row"></div>
            <button type="button" class="btn btn-custom-danger" onclick="window.location.href='../src/form_cadastrar_cliente.php'">Crie uma conta</button>
          </div>
        </form>
      </div>
      <div class="col-md-6">
        <div class="imagem">
          <img src="../img/arte.png" alt="Imagem" class="img-fluid">
        </div>
      </div>
    </div>
  </div>
  <div class="container2">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="topics">
          <div class="topic odd">
            <div class="text-section">
              <h4>Nossa missão</h4>
              <p>Nós acreditamos no poder da arte como um veículo para a expressão humana. Nossa missão é criar um espaço seguro e acessível onde artistas podem compartilhar suas obras e os amantes de arte podem descobrir novas peças para apreciar e adquirir.</p>
            </div>
            <div class="image-section">
              <img src="../img/video_preview_0000.jpg" alt="Imagem Tópico 1" class="img-fluid">
            </div>
          </div>
          <div class="topic even">
            <div class="text-section">
              <h4>Sobre Nós</h4>
              <p>Estamos comprometidos em construir uma plataforma onde os artistas possam prosperar e os compradores possam encontrar peças que ressoem com eles. Temos orgulho de oferecer uma seleção diversificada de obras de arte de todos os tipos de artistas.</p>
            </div>
            <div class="image-section-even">
              <img src="../img/video_preview_0001.jpg" alt="Imagem Tópico 2" class="img-fluid">
            </div>
          </div>
          <div class="topic odd">
            <div class="text-section">
              <h4>Como Funciona?</h4>
              <p>Comprar e vender arte nunca foi tão fácil. Para vender, basta se inscrever, enviar fotos de suas obras e definir um preço. Para comprar, navegue por nossas categorias, encontre uma peça que você ama e conclua a compra com apenas alguns cliques.</p>
            </div>
            <div class="image-section">
              <img src="../img/placeholder.png" alt="Imagem Tópico 3" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    const iconEye = document.querySelector('#icon-eye');
    const inputPassword = document.querySelector('#id_senha');

    iconEye.addEventListener('click', function() {
      if (inputPassword.type === 'password') {
        inputPassword.type = 'text';
        iconEye.classList.remove('fa-eye-slash');
        iconEye.classList.add('fa-eye');
      } else {
        inputPassword.type = 'password';
        iconEye.classList.remove('fa-eye');
        iconEye.classList.add('fa-eye-slash');
      }
    });
  </script>
</body>
</html>
