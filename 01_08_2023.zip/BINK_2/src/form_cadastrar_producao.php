<?php
session_start();
include("../include/cabecalho_logged.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
}

require("../database/funcoes.php");
$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/style_cadastre4.css" rel="stylesheet">
    <script src="js/form_cadastrar_producao.js"></script>
    <script src="js/cadastro_producao.js"></script>

    <style>
        #fundo_form {
            background-color: #000000;
            border-radius: 30px;
            padding: 100px;
        }

        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }
        .container{
            padding:50px !important;
        }
        .btn-custom-success {
            display: block;
            margin-top: 20px;
            border-radius: 20px;
            width: 300px;
            height: 40px;
            color: #ffffff;
            background-color: #00ffda;
            border-color: #00ffda;
            transition: all 0.3s ease; /* para suavizar a transição */
        }

        .btn-custom-success:hover {
            color: #0a0a0a;
            background-color: #01a78e;
            border-color: #01a78e;
        }

    </style>

    <script>
        $(document).ready(function() {
            var etapaCount = 3; // Contador inicial de etapas (já temos 3 etapas no formulário)

            // Função para adicionar uma nova etapa no formulário
            function adicionarEtapa() {
                etapaCount++; // Incrementa o contador de etapas

                var newEtapaDiv =
                    `<div class="form-group col-md-6">
                        <label class="etapas" for="etapa${etapaCount}"><strong>Etapa ${etapaCount}:</strong></label>
                        <input type="text" id="etapa${etapaCount}" name="etapa${etapaCount}" class="form-control">
                    </div>`;

                $("#etapasContainer").append(newEtapaDiv); // Adiciona a nova etapa ao container
            }

            // Evento do clique no botão "Adicionar Etapa"
            $("#btnAdicionarEtapa").click(function(event) {
                event.preventDefault();
                adicionarEtapa();
            });
        });
    </script>
</head>
<body>
<div id="fundo_form" class="container">
<div class="page-wrapper"></div>
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 590" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,200 0,200 C 91.25358851674642,156.1531100478469 182.50717703349284,112.30622009569379 290,128 C 397.49282296650716,143.6937799043062 521.224880382775,218.92822966507174 616,244 C 710.775119617225,269.07177033492826 776.5933014354066,243.98086124401914 855,209 C 933.4066985645934,174.01913875598086 1024.4019138755982,129.14832535885165 1124,126 C 1223.5980861244018,122.85167464114834 1331.7990430622008,161.42583732057417 1440,200 C 1440,200 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="0.53" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 300)"></path><defs><linearGradient id="gradient" x1="0%" y1="50%" x2="100%" y2="50%"><stop offset="5%" stop-color="#001200"></stop><stop offset="95%" stop-color="#00ffda"></stop></linearGradient></defs><path d="M 0,600 C 0,600 0,400 0,400 C 106.07655502392345,356.3062200956938 212.1531100478469,312.6124401913876 297,337 C 381.8468899521531,361.3875598086124 445.46411483253587,453.8564593301436 539,455 C 632.5358851674641,456.1435406698564 755.9904306220094,365.9617224880383 849,361 C 942.0095693779906,356.0382775119617 1004.5741626794259,436.29665071770336 1098,457 C 1191.4258373205741,477.70334928229664 1315.712918660287,438.8516746411483 1440,400 C 1440,400 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1" class="transition-all duration-300 ease-in-out delay-150 path-1" transform="rotate(-180 720 300)"></path></svg>
    <h2>Formulário de Produção</h2>
    <form action="cadastrar_producao.php" method="POST">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label class="etapas" for="tipo_arte"><strong>Tipo de arte:</strong></label>
                <select id="tipo_arte" name="tipo_arte" class="form-control">
                    <option id="animacao" value="Animação" style=''>Animação</option>
                    <option id="desenho" value="Desenho digital" style=''>Desenho digital</option>
                    <option id="desenho_fisico" value="Desenho físico" style=''>Desenho físico</option>
                    <option id="escultura" value="Escultura" style=''>Escultura</option>
                    <option id="pintura" value="Pintura" style=''>Pintura</option>
                </select>
            </div>

            <div class="form-group col-md-6">
                <label class="etapas" for="etapa1"><strong>Etapa 1:</strong></label>
                <input type="text" id="etapa1" name="etapa1" class="form-control">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label class="etapas" for="tempo"><strong>Tempo:</strong></label>
                <input type="number" id="tempo" name="tempo" min="1" placeholder="Horas gastas" class="form-control">
            </div>

            <div class="form-group col-md-6">
                <label class="etapas" for="etapa2"><strong>Etapa 2:</strong></label>
                <input type="text" id="etapa2" name="etapa2" class="form-control">
            </div>
        </div>

        <div class="form-row" id="etapasContainer">
            <div class="form-group col-md-6">
                <label class="etapas" for="etapa3"><strong>Etapa 3:</strong></label>
                <input type="text" id="etapa3" name="etapa3" class="form-control">
            </div>
        </div>

        <button id="btnAdicionarEtapa" type="button" class="btn btn-custom-primary">Adicionar Etapa</button>

        <button type="submit" class="btn btn-custom-primary">Cadastrar Produção</button>

       <a href="cadastrar_producao.php" class="btn btn-custom-primary">cancelar</a> 
    </form>
</div>
</body>
</html>