<?php
// Inicie a sessão
session_start();

// Conexão com o banco de dados
$servername = "localhost";
$username = "web";
$password = "web";
$dbname = "bink";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Verifica se o botão "Iniciar Transição" foi clicado
if (isset($_POST['iniciar_transicao'])) {
    // Obtém o ID do cliente/artista da sessão
    if (isset($_SESSION['usuario_id'])) {
        $id_cliente = $_SESSION['usuario_id'];

        // Obtém o ID do tipo de arte selecionado (substitua 1 pelo ID correto do tipo de arte)
        $id_tipo_arte = 1;

        // Insere os dados na tabela "artista"
        $sql = "INSERT INTO artista (id_cliente, id_tipo_arte) VALUES ($id_cliente, $id_tipo_arte)";
        if ($conn->query($sql) === TRUE) {
            // Atualiza o valor da coluna "is_artist" para 1 (verdadeiro)
            $sql_update_cliente = "UPDATE cliente SET is_artist = 1 WHERE id_cliente = $id_cliente";
            if ($conn->query($sql_update_cliente) === FALSE) {
                echo "Erro ao atualizar o status de artista do cliente: " . $conn->error;
            }
            
            // A transição foi concluída com sucesso, redireciona para o perfil
            header("Location: perfil.php");
            exit();
        } else {
            echo "Erro ao iniciar a transição: " . $conn->error;
        }
    } else {
        echo "ID do cliente não fornecido.";
    }
}

$conn->close();
?>
