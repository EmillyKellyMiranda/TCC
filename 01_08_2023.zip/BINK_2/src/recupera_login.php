<?php
    require ("../database/funcoes.php");
    
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $usuario = buscarUsuario($email, $senha);
    if ($usuario == null){
        session_start();
        $_SESSION["mensagem_erro"] = "Email ou senha inválidos.";
        header("Location: ../public/index.php");
    } else {
        $_SESSION["usuario_logado"] = $usuario["nome"];
        $_SESSION["usuario_id"] = $usuario["id_cliente"]; // Adicione esta linha
        header("Location: perfil.php");
    }
?>
