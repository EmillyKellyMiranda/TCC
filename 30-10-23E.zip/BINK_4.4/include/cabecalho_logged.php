<!DOCTYPE html>
<html>
<head>
	<title>B.ink</title>
	<!-- link para o CSS do BUTISTREPI -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<!-- Linkizin dos icone -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
	<!-- responsivo -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- fontezinha -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/style_cabecalho_unlogged.css" />
</head>
<body>
	<!-- Navbar -->
	<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
		<a class="navbar-brand ml-5" href="../public/index.php">
			<img src="../img/logo.png">
			<span>B.INK</span>
		</a>
		<form action="../src/artistas_encontrados.php" method="GET">
    <div class="input-group">
        <input class="form-control rounded-pill mr-sm-2" type="text" name="nick" placeholder="Pesquise um artista" aria-label="Search by Nick">
        <button class="btn btn-custom-primary rounded-pill my-2 my-sm-0" type="submit">
            <i class="fas fa-search"></i>
        </button>
    </div>
</form>


		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse ml-5" id="navbarNav">
			<ul class="navbar-nav ml-auto ml-5">
				<li class="nav-item">
					<a class="nav-link" href="../src/sobre.php"> Sobre <i class="fas fa-info-circle ml-1"></i></a>
				</li>
				<li class="nav-item-divider"></li>
				<li class="nav-item">
					<a class="nav-link" href="../src/contato.php"> Contato <i class="fas fa-phone ml-1"></i></a>
				</li>
			</ul>
		</div>
	</nav>
  
  <!-- Link para o JavaScript do Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>