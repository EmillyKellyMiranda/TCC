<!DOCTYPE html>
<html lang="pt">
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/style_cadastre3.css" rel="stylesheet">

    <style>
        #fundo_form {
            background-color: #000000;
            border-radius: 30px;
        }
        h2 {
            margin: 10px;
            padding-bottom: 30px;
            font-family: 'DELAQRUS', sans-serif;
            color: white;
            text-align: start;
        }
        .btn-custom {
            display: block;
            margin-top: 20px;
            border-radius: 100px;
            width: 50px;
            height: 50px;
            color: #ffffff;
            background-color: #00ffda;
            border-color: #00ffda;
            transition: all 0.3s ease; /* para suavizar a transição */
            text-align: top;
        }
    </style>
</head>
<body>





    <div class="page-wrapper"></div>
<link rel="stylesheet" type="text/css" href="../css/style_redefinesenha.css" />
<div class="container">
<svg width="100%" height="100%" id="svg" viewBox="0 0 1440 690" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><defs><linearGradient id="gradient" x1="50%" y1="0%" x2="50%" y2="100%"><stop offset="5%" stop-color="#000000"></stop><stop offset="95%" stop-color="#000000"></stop></linearGradient></defs><path d="M 0,700 C 0,700 0,350 0,350 C 148.2666666666667,411.3333333333333 296.5333333333334,472.66666666666663 479,439 C 661.4666666666666,405.33333333333337 878.1333333333332,276.6666666666667 1044,246 C 1209.8666666666668,215.33333333333331 1324.9333333333334,282.66666666666663 1440,350 C 1440,350 1440,700 1440,700 Z" stroke="none" stroke-width="0" fill="url(#gradient)" fill-opacity="1.0" class="transition-all duration-300 ease-in-out delay-150 path-0" transform="rotate(-180 720 350)"></path></svg>   
<div class="row">
    <div class="col-md-6">
    <?php
ob_start();
session_start();
if (!isset($_SESSION["usuario_logado"])){
    header("Location: ../public/index.php");
}

    if (isset($_SESSION["usuario_logado"])){ ?>
        <div class="text-right">
            <h4 class="mt-5 text-success">Você está logado como <?= $_SESSION["usuario_logado"] ?></h4>
        <?php } ?>
    </div> 
    </div>
    <div class="col-md-6">
      <div class="imagem mb-6">
        <img src="../img/arte.png" alt="Imagem" class="img-fluid">
      </div>
    </div>
</div>
</div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>

<?php

include("../database/funcoes.php");
include("../include/cabecalho_logged.php");


if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    echo($_SESSION["usuario_logado"]);
    
}

echo($_SESSION["usuario_id"]);

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

?>