<?php
include("../database/funcoes.php");

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit; // Encerre o script após redirecionar
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Certifique-se de que os campos existem no formulário HTML e têm o atributo 'name' correspondente
    if (isset($_POST["id_producao"])) {
        $id_producao = $_POST["id_producao"];
    }

    // Certifique-se de que os campos existem no formulário HTML e têm o atributo 'name' correspondente
    if (isset($_POST["producao"])) {
        $producao = $_POST["producao"];
    }

    if (isset($_POST["tipoObra"])) {
        $tipoObra = $_POST["tipoObra"];
    }

    if (isset($_POST["tempo"])) {
        $tempo = $_POST["tempo"];
    }

    if (isset($_POST["etapa1"])) {
        $etapa1 = $_POST["etapa1"];
    }

    if (isset($_POST["etapa2"])) {
        $etapa2 = $_POST["etapa2"];
    }

    if (isset($_POST["etapa3"])) {
        $etapa3 = $_POST["etapa3"];
    }

    $conexao = obterConexao();

    // Verifique a coluna 'producao' na sua consulta SQL e certifique-se de que ela existe na tabela
    $sql = "SELECT producao, arte, tempo, etapa1, etapa2, etapa3 FROM ficha WHERE id_producao_ficha = ?";

    $stmt = mysqli_prepare($conexao, $sql);

    if ($stmt) { // Verifique se a instrução foi criada com sucesso
        mysqli_stmt_bind_param($stmt, "i", $id_producao);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $producao = mysqli_fetch_assoc($result);

            echo "<script>
                document.getElementById('producao').value = '" . $producao['producao'] . "';
                document.getElementById('tipoObra').value = '" . $producao['arte'] . "';
                document.getElementById('tempo').value = '" . $producao['tempo'] . "';
                document.getElementById('etapa1').value = '" . $producao['etapa1'] . "';
                document.getElementById('etapa2').value = '" . $producao['etapa2'] . "';
                document.getElementById('etapa3').value = '" . $producao['etapa3'] . "';
            </script>";
        } else {
            echo "Nenhum resultado encontrado.";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Erro na preparação da consulta SQL: " . mysqli_error($conexao);
    }

    mysqli_close($conexao);
}
?>

