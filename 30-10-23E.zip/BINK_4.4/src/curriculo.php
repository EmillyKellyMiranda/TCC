<?php

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../public/index.php");
    exit();
}

$usuario = buscarUsuarioPorId($_SESSION["usuario_id"]);

$localizacao = isset($usuario["localizacao"]) ? $usuario["localizacao"] : "";
$localizacao2 = isset($usuario["localizacao2"]) ? $usuario["localizacao2"] : "";
$sobre_artista = isset($usuario["sobre_artista"]) ? $usuario["sobre_artista"] : "";
$formacao = isset($usuario["formacao"]) ? $usuario["formacao"] : array();
$estilo_arte = isset($usuario["estilo_arte"]) ? $usuario["estilo_arte"] : "";
$contato = isset($usuario["contato"]) ? $usuario["contato"] : "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $localizacao = isset($_POST["localizacao"]) ? $_POST["localizacao"] : "";
    $localizacao2 = isset($_POST["localizacao2"]) ? $_POST["localizacao2"] : "";
    $sobre_artista = isset($_POST["sobre_artista"]) ? $_POST["sobre_artista"] : "";
    $formacao = isset($_POST["formacao"]) ? $_POST["formacao"] : array();
    $estilo_arte = isset($_POST["estilo_arte"]) ? $_POST["estilo_arte"] : "";
    $contato = isset($_POST["contato"]) ? $_POST["contato"] : "";

    $conexao = obterConexao();

    if ($conexao) {
        if (existeCurriculo($usuario["id_cliente"])) {
            atualizarCurriculo($usuario["id_cliente"], $localizacao, $localizacao2, $sobre_artista, $formacao, $estilo_arte, $contato);
        } else {
            cadastrarCurriculo($usuario["id_cliente"], $localizacao, $localizacao2, $sobre_artista, $formacao, $estilo_arte, $contato);
        }

        mysqli_close($conexao);
    } else {
        echo "Erro na conexão com o banco de dados!";
    }
}

function existeCurriculo($id_cliente) {
    $conexao = obterConexao();
    $sql = "SELECT COUNT(*) FROM curriculo WHERE id_artista = ?";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_cliente);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $count);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conexao);
    return $count > 0;
}

function cadastrarCurriculo($id_cliente, $localizacao, $localizacao2, $sobre_artista, $formacao, $estilo_arte, $contato) {
    $conexao = obterConexao();
    $formacao_str = implode(", ", $formacao); // converte o array em uma string separada por vírgulas
    $sql = "INSERT INTO curriculo (id_artista, localizacao, localizacao2, sobre_artista, formacao, estilo_arte, contato) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "issssss", $id_cliente, $localizacao, $localizacao2, $sobre_artista, $formacao_str, $estilo_arte, $contato);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conexao);
}

function atualizarCurriculo($id_cliente, $localizacao, $localizacao2, $sobre_artista, $formacao, $estilo_arte, $contato) {
    $conexao = obterConexao();
    $formacao_str = implode(", ", $formacao); // converte o array em uma string separada por vírgulas
    $sql = "UPDATE curriculo SET localizacao = ?, localizacao2 = ?, sobre_artista = ?, formacao = ?, estilo_arte = ?, contato = ? WHERE id_artista = ?";
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, "ssssssi", $localizacao, $localizacao2, $sobre_artista, $formacao_str, $estilo_arte, $contato, $id_cliente);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conexao);
}
?>
