<?php

    $conexao = obterConexao();

if (isset($_POST['tipoObra'])) {
    $tipoObra = $_POST['tipoObra'];

    // Consulta SQL para obter as etapas de produção com base no tipo de obra
    $sql = "SELECT etapa1, etapa2, etapa3 FROM producao WHERE arte = '$tipoObra'";
    
    // Execute a consulta e obtenha as etapas de produção
    $result = mysqli_query($conexao, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        echo json_encode($row);
    } else {
        echo json_encode(array());
    }
} else {
    echo json_encode(array());
}
?>
