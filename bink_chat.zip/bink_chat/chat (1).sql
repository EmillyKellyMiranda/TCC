CREATE DATABASE bate_papo;
USE bate_papo;

-- Tabela de usuários
CREATE TABLE usuarios (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    nome_usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL
);

-- Tabela de mensagens
CREATE TABLE mensagens (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    id_sala INT(11) NOT NULL,
    id_remetente INT(11) NOT NULL,
    nome_remetente VARCHAR(50) NOT NULL,
    mensagem TEXT NOT NULL,
    horario TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de salas de bate-papo
CREATE TABLE salas_de_bate_papo (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    id_usuario1 INT(11) NOT NULL,
    id_usuario2 INT(11) NOT NULL,
    UNIQUE (id_usuario1, id_usuario2)
);

-- Adicionando chaves estrangeiras à tabela salas_de_bate_papo
ALTER TABLE salas_de_bate_papo
ADD FOREIGN KEY (id_usuario1) REFERENCES usuarios(id),
ADD FOREIGN KEY (id_usuario2) REFERENCES usuarios(id);

-- Adicionando chaves estrangeiras à tabela mensagens
ALTER TABLE mensagens
ADD FOREIGN KEY (id_sala) REFERENCES salas_de_bate_papo(id),
ADD FOREIGN KEY (id_remetente) REFERENCES usuarios(id);
