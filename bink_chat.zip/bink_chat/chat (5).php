
<?php
// Iniciando a sessão para acessar o nome do usuário logado
session_start();
$sender_name = $_SESSION['user_name'];
?>


<?php
include_once 'backend.php';
$user_id = $_GET['user_id'] ?? null;
if ($user_id === null) {
    header("Location: user_list.php");
    exit();
}

$logged_in_user_id = checkSession();
if ($logged_in_user_id === null) {
    header("Location: login.php");
    exit();
}

$sender_id = min($logged_in_user_id, $user_id);
$receiver_id = max($logged_in_user_id, $user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script defer src="frontend.js"></script>
    <title>Chat</title>
</head>
<body>
    <div id="messages"></div>
    <input type="text" id="messageInput">
    <button onclick="sendMessage(<?php echo $sender_id; ?>, '<?php echo $sender_name; ?>', <?php echo $receiver_id; ?>, document.getElementById('messageInput').value)">Send</button>
    <button onclick="fetchMessages(<?php echo $sender_id; ?>, <?php echo $receiver_id; ?>)">Update Messages</button>
</body>
</html>

