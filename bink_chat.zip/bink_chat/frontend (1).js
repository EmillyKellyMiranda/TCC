
function sendMessage(user1Id, user2Id, message) {
    const senderId = Math.min(user1Id, user2Id);
    const receiverId = Math.max(user1Id, user2Id);
    fetch('backend.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `sender_id=${senderId}&receiver_id=${receiverId}&message=${message}`,
    }).then(response => {
        if (!response.ok) {
            alert("Error sending message.");
        }
    });
}

function fetchMessages(user1Id, user2Id) {
    const senderId = Math.min(user1Id, user2Id);
    const receiverId = Math.max(user1Id, user2Id);
    fetch(`backend.php?receiver_id=${receiverId}&sender_id=${senderId}`)
        .then(response => response.text())
        .then(messages => {
            document.getElementById('messages').innerHTML = messages;
        });
}
