
<?php
include_once 'db_connection.php';
$conn = connect_db();

// Verificar sessão
if (!function_exists('checkSession')) {
    function checkSession() {
        session_start();
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}

// Obter ou criar chatroom_id
function getOrCreateChatroomId($user1_id, $user2_id, $conn) {
    $stmt = $conn->prepare("SELECT id FROM chatrooms WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)");
    $stmt->bind_param("iiii", $user1_id, $user2_id, $user2_id, $user1_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['id'];
    } else {
        $stmt = $conn->prepare("INSERT INTO chatrooms (user1_id, user2_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user1_id, $user2_id);
        $stmt->execute();
        return $conn->insert_id;
    }
}

// Insere uma nova mensagem
if (isset($_POST['sender_id'], $_POST['sender_name'], $_POST['receiver_id'], $_POST['message'])) {
    $chatroom_id = getOrCreateChatroomId($_POST['sender_id'], $_POST['receiver_id'], $conn);
    $stmt = $conn->prepare("INSERT INTO messages (chatroom_id, sender_id, sender_name, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $chatroom_id, $_POST['sender_id'], $_POST['sender_name'], $_POST['message']);
    $stmt->execute();
    $stmt->close();
}

// Busca mensagens
if (isset($_GET['receiver_id'], $_GET['sender_id'])) {
    $chatroom_id = getOrCreateChatroomId($_GET['sender_id'], $_GET['receiver_id'], $conn);
    $stmt = $conn->prepare("SELECT * FROM messages WHERE chatroom_id = ? ORDER BY timestamp DESC");
    $stmt->bind_param("i", $chatroom_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        echo $row['sender_name'] . ": " . $row['message'] . "<br>";
    }
    $stmt->close();
}
?>

