
<?php
include_once 'db_connection.php';
$conn = connect_db();

// Busca todos os usuários do banco de dados
$result = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
</head>

    <body>
        <h1>Bem-vindo, <?php echo $_SESSION['user_name']; ?>!</h1>
    
    <ul>
        
    <?php while ($row = $result->fetch_assoc()): 
        if ($_SESSION['user_id'] == $row['id']) continue;
    ?>
    
            <li>
                <a href="chat.php?user_id=<?php echo $row['id']; ?>&username=<?php echo $row['username']; ?>"><?php echo $row['username']; ?></a>
            </li>
        <?php endwhile; ?>
    </ul>
</body>
</html>
