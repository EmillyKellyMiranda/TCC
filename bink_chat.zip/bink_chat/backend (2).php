
<?php
include_once 'db_connection.php';
$conn = connect_db();

// Verificar sessão
if (!function_exists('checkSession')) {
    function checkSession() {
        session_start();
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}

// Restante do código continua igual
?>

<?php
include 'db_connection.php';
$conn = connect_db();

// Insere uma nova mensagem
if (isset($_POST['sender_id'], $_POST['receiver_id'], $_POST['message'])) {
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $_POST['sender_id'], $_POST['receiver_id'], $_POST['message']);
    $stmt->execute();
    $stmt->close();
}

// Busca mensagens
if (isset($_GET['receiver_id'])) {
    $stmt = $conn->prepare("SELECT * FROM messages WHERE receiver_id = ? ORDER BY timestamp DESC");
    $stmt->bind_param("i", $_GET['receiver_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        echo $row['message'] . "<br>";
    }
    $stmt->close();
}

// Login
if (isset($_POST['username'], $_POST['password'])) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $_POST['username']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    
    if (password_verify($_POST['password'], $user['password'])) {
        session_start();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
    } else {
        echo "Invalid credentials.";
    }

    $stmt->close();
}

// Verificar sessão
function checkSession() {
    session_start();
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

?>
