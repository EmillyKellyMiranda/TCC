
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+z0I5t9z5lFf5r5l5u5z5F5w5f5Oj04meM1a7xj" crossorigin="anonymous">
    <script defer src="frontend.js"></script>
    <title>Chat</title>
    <style>
        .message {
            max-width: 80%;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 10px;
            position: relative;
        }
        .message.sent {
            background-color: #DCF8C6;
            align-self: flex-end;
            border-bottom-right-radius: 0;
        }
        .message.received {
            background-color: #efefef;
            align-self: flex-start;
            border-bottom-left-radius: 0;
        }
        #messages {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h1>CHAT COM '<?php echo isset($_GET['username']) ? $_GET['username'] : ""; ?>'</h1>
        <div class="card">
            <div class="card-body" id="messages" style="height: 300px; overflow-y: scroll;">
                <!-- As mensagens serão carregadas aqui -->
            </div>
        </div>
        <div class="mt-3">
            <input type="text" id="messageInput" class="form-control" placeholder="Digite sua mensagem...">
            <button onclick="sendMessage(<?php echo $sender_id; ?>, '<?php echo $sender_name; ?>', <?php echo $receiver_id; ?>, document.getElementById('messageInput').value)" class="btn btn-primary mt-2">Enviar</button>
        </div>
    </div>

    <script>
        var sender_id = <?php echo $sender_id; ?>;
        var receiver_id = <?php echo $receiver_id; ?>;
    </script>
</body>
</html>
