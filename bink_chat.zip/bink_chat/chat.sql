-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25/09/2023 às 17:44
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `chat`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `chatrooms`
--

CREATE TABLE `chatrooms` (
  `id` int(11) NOT NULL,
  `user1_id` int(11) DEFAULT NULL,
  `user2_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `chatrooms`
--

INSERT INTO `chatrooms` (`id`, `user1_id`, `user2_id`) VALUES
(3, 1, 1),
(1, 1, 3),
(7, 1, 6),
(8, 1, 7),
(2, 3, 3),
(9, 3, 6),
(5, 4, 4),
(4, 4, 5),
(6, 6, 7);

-- --------------------------------------------------------

--
-- Estrutura para tabela `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `chatroom_id` varchar(255) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `chat_id` varchar(255) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `messages`
--

INSERT INTO `messages` (`id`, `chatroom_id`, `sender_id`, `message`, `timestamp`, `chat_id`, `sender_name`) VALUES
(1, '1-3', 1, 'cara', '2023-09-25 04:20:24', NULL, NULL),
(2, NULL, 1, 'doido', '2023-09-25 04:24:43', '1-3', NULL),
(3, NULL, 3, 'a', '2023-09-25 04:25:01', '3-3', NULL),
(4, '1', 1, 'fuck you', '2023-09-25 04:31:17', NULL, NULL),
(5, '2', 3, 'ca', '2023-09-25 04:31:33', NULL, NULL),
(6, '2', 3, 'ca', '2023-09-25 04:31:34', NULL, NULL),
(7, '2', 3, 'ca', '2023-09-25 04:31:34', NULL, NULL),
(8, '1', 1, 'ca', '2023-09-25 04:55:39', NULL, 'lixo'),
(9, '1', 1, 'aa', '2023-09-25 04:59:02', NULL, 'lixo'),
(10, '3', 1, 'a', '2023-09-25 04:59:19', NULL, 'christian'),
(11, '3', 1, 'as', '2023-09-25 04:59:26', NULL, 'christian'),
(12, '4', 4, 'Oi jose', '2023-09-25 05:00:34', NULL, 'Otavio'),
(13, '4', 4, 'Oi otavio', '2023-09-25 05:00:55', NULL, 'Jose'),
(14, '4', 4, 'a', '2023-09-25 05:05:23', NULL, 'Otavio'),
(15, '4', 4, 'asa', '2023-09-25 05:05:26', NULL, 'Otavio'),
(16, '4', 4, 'asaasd', '2023-09-25 05:05:27', NULL, 'Otavio'),
(17, '4', 4, 'a', '2023-09-25 05:05:31', NULL, 'Jose'),
(18, '4', 4, 'adsadsda', '2023-09-25 05:05:36', NULL, 'Jose'),
(19, '4', 4, 'adsadsdaasd', '2023-09-25 05:05:37', NULL, 'Jose'),
(20, '4', 4, 'asaasd', '2023-09-25 05:05:44', NULL, 'Otavio'),
(21, '4', 4, 'a', '2023-09-25 05:11:43', NULL, 'Otavio'),
(22, '4', 4, 'as', '2023-09-25 05:11:47', NULL, 'Otavio'),
(23, '4', 4, 'asss', '2023-09-25 05:11:49', NULL, 'Otavio'),
(24, '6', 6, 'oi', '2023-09-25 05:17:38', NULL, 'Emilly'),
(25, '6', 6, 'tchau', '2023-09-25 05:18:06', NULL, 'Thais'),
(26, '7', 1, '', '2023-09-25 14:41:29', NULL, 'christian'),
(27, '7', 1, '', '2023-09-25 14:41:30', NULL, 'christian'),
(28, '7', 1, 'as', '2023-09-25 14:41:32', NULL, 'christian'),
(29, '7', 1, 'sa', '2023-09-25 14:42:20', NULL, 'christian'),
(30, '9', 3, 'ca', '2023-09-25 14:54:42', NULL, 'lixo'),
(31, '9', 3, 'ta doido', '2023-09-25 14:54:47', NULL, 'lixo'),
(32, '9', 3, 'a', '2023-09-25 15:02:03', NULL, 'lixo'),
(33, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(34, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(35, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(36, '9', 3, 'a', '2023-09-25 15:02:05', NULL, 'lixo'),
(37, '9', 3, 'a', '2023-09-25 15:13:31', NULL, 'lixo'),
(38, '9', 3, 'aaa', '2023-09-25 15:13:34', NULL, 'lixo'),
(39, '9', 3, 'a', '2023-09-25 15:13:37', NULL, 'lixo'),
(40, '7', 1, 'va', '2023-09-25 15:16:23', NULL, 'christian'),
(41, '7', 1, 'va', '2023-09-25 15:16:30', NULL, 'christian'),
(42, '2', 3, 'a', '2023-09-25 15:16:48', NULL, 'lixo'),
(43, '2', 3, 'asd', '2023-09-25 15:34:24', NULL, 'lixo'),
(44, '2', 3, 'asd', '2023-09-25 15:34:24', NULL, 'lixo'),
(45, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(46, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(47, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(48, '2', 3, 'asd', '2023-09-25 15:34:25', NULL, 'lixo'),
(49, '2', 3, 'asd', '2023-09-25 15:34:26', NULL, 'lixo'),
(50, '1', 1, 'sa', '2023-09-25 15:40:25', NULL, 'christian'),
(51, '1', 1, 'saasd', '2023-09-25 15:40:30', NULL, 'christian'),
(52, '2', 3, 'a', '2023-09-25 15:42:23', NULL, 'lixo'),
(53, '1', 1, 'a', '2023-09-25 15:43:16', NULL, 'christian'),
(54, '1', 1, 'aasf', '2023-09-25 15:43:18', NULL, 'christian'),
(55, '1', 1, 'aasfaf', '2023-09-25 15:43:20', NULL, 'christian'),
(56, '1', 1, 'aasfafasf', '2023-09-25 15:43:21', NULL, 'christian');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'christian', '$2y$10$iHAeGSic99sq4f7m26Wy2OOSxs.dNjhTFONMCBOV4/x.cHHpQF7Re'),
(3, 'lixo', '$2y$10$PmZWr6U6/g/BSpBUCrR8FOPPA4nstIZw/JmKuCrCAixqSv/DQXoAC'),
(4, 'Jose', '$2y$10$SqSBgedYOXbznWwFpeHbJ.Ufvfw9bqbjdkfoB34vvvsqfqJfdU2dW'),
(5, 'Otavio', '$2y$10$Tppc1AfsJFSdZDDQjKjeAORnHzHVIk4IgfqE0pIJx8d.UitQ3GSkK'),
(6, 'Thais', '$2y$10$3dEpJBRN4FWU.aMXYCkWrOL6cPWEJ0byX/aiZqZiq6Z55ZZ6CKTx.'),
(7, 'Emilly', '$2y$10$p9gXlaUQB86UZBPgMB.CKe6nbNTRbzKpUGSFfpSw1HuJDBrXyEZtO');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `chatrooms`
--
ALTER TABLE `chatrooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user1_id` (`user1_id`,`user2_id`);

--
-- Índices de tabela `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `chatrooms`
--
ALTER TABLE `chatrooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
