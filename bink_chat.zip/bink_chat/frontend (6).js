
function fetchMessages(sender_id, receiver_id) {
    fetch(`backend.php?action=fetch_messages&sender_id=${sender_id}&receiver_id=${receiver_id}`)
        .then(response => response.json())
        .then(messages => {
            const messagesDiv = document.getElementById('messages');
            messagesDiv.innerHTML = ''; // Limpar as mensagens anteriores
            messages.forEach(message => {
                displayMessage(message.content, message.sender_name, message.sender_id === sender_id ? 'sent' : 'received');
            });
        });
}

function displayMessage(message, userName, type) {
    const messagesDiv = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(type); // Adicionando a classe 'sent' ou 'received'
    messageDiv.innerText = message;
    messagesDiv.appendChild(messageDiv);
}

setInterval(function() {
    fetchMessages(sender_id, receiver_id);
}, 5000);
