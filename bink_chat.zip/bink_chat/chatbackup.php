



<?php
include_once 'backend.php';
$user_id = $_GET['user_id'] ?? null;
if ($user_id === null) {
    header("Location: user_list.php");
    exit();
}

$logged_in_user_id = checkSession();
if ($logged_in_user_id === null) {
    header("Location: login.php");
    exit();
}

$sender_id = min($logged_in_user_id, $user_id);
$receiver_id = max($logged_in_user_id, $user_id);
?>
<?php
// Iniciando a sessão para acessar o nome do usuário logado

$sender_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+z0I5t9z5lFf5r5l5u5z5F5w5f5Oj04meM1a7xj" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <script defer src="frontend.js"></script>
    <link rel="stylesheet" href="styles.css">
    <title>Chat</title>

</head>
<body>
    <div class="container">
        <h1 class="text-white my-3">Bem vindo '<?php echo $sender_name; ?>'</h1>
        <div id="messages" class="mb-3"></div>
        <div class="input-group">
            <input type="text" id="messageInput" class="form-control" placeholder="Digite sua mensagem...">
            <button class="btn btn-primary" onclick="sendMessage(<?php echo $sender_id; ?>, '<?php echo $sender_name; ?>', <?php echo $receiver_id; ?>, document.getElementById('messageInput').value)">
                Enviar <i class="fas fa-paper-plane"></i>
            </button>
        </div>
        <button class="btn btn-secondary mt-3" onclick="fetchMessages(<?php echo $sender_id; ?>, <?php echo $receiver_id; ?>)">
            Carregar mensagens <i class="fas fa-sync-alt"></i>
        </button>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.css" integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+z0I5t9z5lFf5r5l5u5z5F5w5f5Oj04meM1a7xj" crossorigin="anonymous"></script>
</body>
</html>


