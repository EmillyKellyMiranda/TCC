SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
CREATE TABLE `salaschat` (
`id` int(11) NOT NULL,
`id_usuario1` int(11) DEFAULT NULL,
`id_usuario2` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE `mensagems` (
`id` int(11) NOT NULL,
`id_sala_chat` varchar(255) DEFAULT NULL,
`id_remetente` int(11) DEFAULT NULL,
`mensagem` text DEFAULT NULL,
`data_hora` data_hora NOT NULL DEFAULT current_data_hora(),
`chat_id` varchar(255) DEFAULT NULL,
`nome_remetente` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE `users` (
`id` int(11) NOT NULL,
`nome_usuario` varchar(50) NOT NULL,
`senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
ALTER TABLE `salaschat`
ADD PRIMARY KEY (`id`),
ADD UNIQUE KEY `id_usuario1` (`id_usuario1`,`id_usuario2`);
ALTER TABLE `mensagems`
ADD PRIMARY KEY (`id`);
ALTER TABLE `users`
ADD PRIMARY KEY (`id`),
ADD UNIQUE KEY `nome_usuario` (`nome_usuario`);
ALTER TABLE `salaschat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `mensagems`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;