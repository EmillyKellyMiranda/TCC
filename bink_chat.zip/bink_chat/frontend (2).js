
function sendMessage(user1Id, user2Id, message) {
    fetch('backend.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `sender_id=${user1Id}&receiver_id=${user2Id}&message=${message}`,
    }).then(response => {
        if (!response.ok) {
            alert("Error sending message.");
        }
    });
}

function fetchMessages(user1Id, user2Id) {
    fetch(`backend.php?receiver_id=${user2Id}&sender_id=${user1Id}`)
        .then(response => response.text())
        .then(messages => {
            document.getElementById('messages').innerHTML = messages;
        });
}
