
<?php
// Iniciando a sessão para acessar o nome do usuário logado
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <script src="frontend.js" defer></script>
</head>
<body>
    <div id="messages"></div>
    <input type="text" id="messageInput">
    <button onclick="sendMessage(<?php echo $_SESSION['user_id']; ?>, '<?php echo $_SESSION['user_name']; ?>', <?php echo $_GET['receiver_id']; ?>, document.getElementById('messageInput').value)">Send</button>
</body>
</html>
