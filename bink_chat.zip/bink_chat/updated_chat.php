
<?php
include_once 'backend.php';
$user_id = $_GET['user_id'] ?? null;
if ($user_id === null) {
    header("Location: user_list.php");
    exit();
}

$logged_in_user_id = checkSession();
if ($logged_in_user_id === null) {
    header("Location: login.php");
    exit();
}

$sender_id = min($logged_in_user_id, $user_id);
$receiver_id = max($logged_in_user_id, $user_id);
$sender_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Exemplo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+z0I5t9z5lFf5r5l5u5z5F5w5f5Oj04meM1a7xj" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <script defer src="frontend.js"></script>
    <style>
        .chat-container {
            max-width: 400px;
            height: 500px;
            margin: auto;
            border: 1px solid #ccc;
            border-radius: 25px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
        }

        .chat-messages {
            flex-grow: 1;
            overflow-y: scroll;
            margin-bottom: 10px;
            border-radius: 20px;
        }

        .chat-messages p {
            border-radius: 20px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            margin: 5px;
            max-width: 80%;
            animation: wipeUp 0.5s ease;
        }

        .chat-footer {
            display: flex;
            gap: 10px;
        }

        @keyframes wipeUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-white my-3">Bem vindo '<?php echo $sender_name; ?>'</h1>
        <div class="chat-container">
            <div class="chat-messages" id="chat-messages">
                <!-- Mensagens do chat aqui -->
            </div>
            <div class="chat-footer">
                <input type="text" id="messageInput" class="form-control" placeholder="Digite sua mensagem...">
                <button class="btn btn-primary" onclick="sendMessage(<?php echo $sender_id; ?>, '<?php echo $sender_name; ?>', <?php echo $receiver_id; ?>, document.getElementById('messageInput').value)">
                    Enviar <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
        <button class="btn btn-secondary mt-3" onclick="fetchMessages(<?php echo $sender_id; ?>, <?php echo $receiver_id; ?>)">
            Carregar mensagens <i class="fas fa-sync-alt"></i>
        </button>
    </div>
</body>
</html>
