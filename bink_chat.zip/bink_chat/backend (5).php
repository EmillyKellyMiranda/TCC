
<?php
include_once 'db_connection.php';
$conn = connect_db();

// Verificar sessão
if (!function_exists('checkSession')) {
    function checkSession() {
        session_start();
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}

// Insere uma nova mensagem
if (isset($_POST['sender_id'], $_POST['receiver_id'], $_POST['message'])) {
    $chat_id = $_POST['sender_id'] < $_POST['receiver_id'] ? "{$_POST['sender_id']}-{$_POST['receiver_id']}" : "{$_POST['receiver_id']}-{$_POST['sender_id']}";
    $stmt = $conn->prepare("INSERT INTO messages (chat_id, sender_id, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $chat_id, $_POST['sender_id'], $_POST['message']);
    $stmt->execute();
    $stmt->close();
}

// Busca mensagens
if (isset($_GET['receiver_id'], $_GET['sender_id'])) {
    $chat_id = $_GET['sender_id'] < $_GET['receiver_id'] ? "{$_GET['sender_id']}-{$_GET['receiver_id']}" : "{$_GET['receiver_id']}-{$_GET['sender_id']}";
    $stmt = $conn->prepare("SELECT * FROM messages WHERE chat_id = ? ORDER BY timestamp DESC");
    $stmt->bind_param("s", $chat_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        echo $row['message'] . "<br>";
    }
    $stmt->close();
}
?>

