
function sendMessage(senderId, senderName, receiverId, message) {
    fetch('backend.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `sender_id=${senderId}&sender_name=${senderName}&receiver_id=${receiverId}&message=${message}`,
    }).then(response => {
        if (!response.ok) {
            alert("Error sending message.");
        }
    }).then(() => {
        fetchMessages(senderId, receiverId); // Atualiza as mensagens após enviar uma nova mensagem
    });
}
function displayMessage(message, userName) {
    const messagesDiv = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');

    // Adicionando um ícone de perfil ao lado de cada mensagem
    messageDiv.innerHTML = `
        <div class="d-flex align-items-start">
            <i class="bi bi-person-circle profile-icon me-2"></i>
            <div>
                <strong>${userName}:</strong> ${message}
            </div>
        </div>`;
    
    messagesDiv.appendChild(messageDiv);
}

function fetchMessages(senderId, receiverId) {
    fetch(`backend.php?receiver_id=${receiverId}&sender_id=${senderId}`)
        .then(response => response.text())
        .then(messages => {
            document.getElementById('messages').innerHTML = messages;
        });
}

// Busca novas mensagens a cada 2 segundos (2000 milissegundos)
setInterval(() => {
    const senderId = document.getElementById('senderId').value;
    const receiverId = document.getElementById('receiverId').value;
    fetchMessages(senderId, receiverId);
}, 2000);

setInterval(function() {
    fetchMessages(sender_id, receiver_id);
}, 5000);
